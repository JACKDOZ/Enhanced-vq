package com.homequest.block;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import com.mojang.math.Transformation;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.object.chest.ChestModel;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.client.renderer.blockentity.state.BlockEntityRenderState;
import net.minecraft.client.renderer.feature.ModelFeatureRenderer;
import net.minecraft.client.renderer.rendertype.RenderType;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.client.renderer.state.level.CameraRenderState;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.core.Direction;
import net.minecraft.resources.Identifier;
import net.minecraft.world.level.block.ChestBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;

/**
 * Renderer del Cofre de Quest — cofre 100% real y funcional (misma base que se validó en
 * el mod de prueba chesttest): usa el ChestModel real de Minecraft (misma animación de tapa
 * que un cofre vanilla) con nuestra propia textura independiente
 * (textures/entity/chest/quest_chest.png), sin tocar ningún recurso vanilla compartido.
 */
public class QuestChestRenderer implements BlockEntityRenderer<QuestChestBlockEntity, QuestChestRenderState> {

    public static final ModelLayerLocation LAYER_SINGLE =
        new ModelLayerLocation(Identifier.fromNamespaceAndPath("homequest", "quest_chest"), "single");
    public static final ModelLayerLocation LAYER_LEFT =
        new ModelLayerLocation(Identifier.fromNamespaceAndPath("homequest", "quest_chest"), "left");
    public static final ModelLayerLocation LAYER_RIGHT =
        new ModelLayerLocation(Identifier.fromNamespaceAndPath("homequest", "quest_chest"), "right");

    private static final Identifier TEXTURE =
        Identifier.fromNamespaceAndPath("homequest", "textures/entity/chest/quest_chest.png");

    private final ChestModel singleModel;
    private final ChestModel leftModel;
    private final ChestModel rightModel;

    public QuestChestRenderer(BlockEntityRendererProvider.Context context) {
        this.singleModel = new ChestModel(context.bakeLayer(LAYER_SINGLE));
        this.leftModel = new ChestModel(context.bakeLayer(LAYER_LEFT));
        this.rightModel = new ChestModel(context.bakeLayer(LAYER_RIGHT));
    }

    @Override
    public QuestChestRenderState createRenderState() {
        return new QuestChestRenderState();
    }

    @Override
    public void extractRenderState(QuestChestBlockEntity entity, QuestChestRenderState state, float tickProgress,
                                    Vec3 cameraPos, ModelFeatureRenderer.CrumblingOverlay crumblingOverlay) {
        BlockEntityRenderState.extractBase(entity, state, crumblingOverlay);
        BlockState blockState = entity.getBlockState();
        state.facing = blockState.getValue(ChestBlock.FACING);
        state.type = blockState.getValue(ChestBlock.TYPE);
        state.open = entity.getOpenNess(tickProgress);
    }

    @Override
    public void submit(QuestChestRenderState state, PoseStack pose, SubmitNodeCollector collector,
                        CameraRenderState camera) {
        ChestModel model = switch (state.type) {
            case LEFT -> leftModel;
            case RIGHT -> rightModel;
            default -> singleModel;
        };

        pose.pushPose();
        pose.mulPose(modelTransformation(state.facing));

        // misma curva de easing que usa vanilla para la animacion de la tapa: f = 1-(1-open)^3
        float f = state.open;
        f = 1.0f - f;
        f = 1.0f - f * f * f;

        RenderType renderType = RenderTypes.entitySolid(TEXTURE);
        collector.order(0).submitModel(model, f, pose, renderType,
            state.lightCoords, OverlayTexture.NO_OVERLAY, 0, state.breakProgress);

        pose.popPose();
    }

    private static Transformation modelTransformation(Direction direction) {
        Matrix4f matrix = new Matrix4f()
            .rotationAround(Axis.YP.rotationDegrees(-direction.toYRot()), 0.5f, 0f, 0.5f);
        return new Transformation(matrix);
    }
}
