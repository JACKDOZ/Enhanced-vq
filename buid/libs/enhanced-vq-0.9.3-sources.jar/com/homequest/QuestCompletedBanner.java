package com.homequest;

import com.homequest.data.QuestData;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.resources.Identifier;

import java.util.ArrayDeque;
import java.util.Deque;

/**
 * Cartel "Quest Completada" en la esquina superior izquierda de la pantalla (HUD,
 * no la pantalla del libro). Se dispara desde HomeQuestClient cada vez que llega
 * un sync con una misión nueva marcada como completada.
 *
 * Fases (todas usan recorte/scissor, no transparencia real — blit() en esta versión
 * no tiene un overload con alpha/tint confirmado, así que no arriesgamos algo que
 * podría no compilar o no verse bien):
 *   1. Barrido de entrada, izquierda→derecha (450ms) — no especificado por el pedido
 *      original, elegido para que se sienta rápido y notorio sin ser brusco.
 *   2. Sostenido, completamente visible (3000ms, tal cual se pidió).
 *   3. Salida (900ms): se cierra como una cortina hacia el centro, en vez de un
 *      barrido igual al de entrada, para que se sienta distinto a "desvanecer" y no
 *      a "la animación de entrada al revés".
 *
 * Si se completa más de una misión antes de que termine el cartel actual, las
 * siguientes se encolan y se muestran una después de la otra (nunca se pisan ni se
 * pierden).
 */
public final class QuestCompletedBanner {
    private QuestCompletedBanner() {}

    private static final Identifier BANNER_EN = Identifier.fromNamespaceAndPath("homequest", "textures/gui/banners/quest_completed_en.png");
    private static final Identifier BANNER_ES = Identifier.fromNamespaceAndPath("homequest", "textures/gui/banners/quest_completed_es.png");
    private static final int BANNER_EN_W = 1289, BANNER_EN_H = 310;
    private static final int BANNER_ES_W = 1293, BANNER_ES_H = 310;

    private static final int DISPLAY_H = 40; // alto en pantalla; el ancho se escala preservando el aspect ratio de cada imagen
    private static final int MARGIN_X = 10, MARGIN_Y = 10;

    private static final long SWEEP_IN_MS  = 450;
    private static final long HOLD_MS      = 3000;
    private static final long FADE_OUT_MS  = 900;
    private static final long TOTAL_MS     = SWEEP_IN_MS + HOLD_MS + FADE_OUT_MS;

    private static final Deque<Object> queue = new ArrayDeque<>();
    private static long currentStart = -1L;

    /** Llamar una vez por cada misión que se acaba de completar. */
    public static void trigger() {
        if (currentStart < 0) {
            currentStart = System.currentTimeMillis();
        } else {
            queue.add(Boolean.TRUE); // el valor no importa, solo cuenta como "uno más pendiente"
        }
    }

    public static void render(GuiGraphicsExtractor g, Minecraft client) {
        if (currentStart < 0) return;
        long now = System.currentTimeMillis();
        long elapsed = now - currentStart;

        if (elapsed >= TOTAL_MS) {
            if (!queue.isEmpty()) {
                queue.poll();
                currentStart = now;
                elapsed = 0;
            } else {
                currentStart = -1L;
                return;
            }
        }

        boolean english = client.player != null && "en".equals(QuestData.get().getLanguage(client.player.getUUID()));
        Identifier tex = english ? BANNER_EN : BANNER_ES;
        int texW = english ? BANNER_EN_W : BANNER_ES_W;
        int texH = english ? BANNER_EN_H : BANNER_ES_H;

        int dispH = DISPLAY_H;
        int dispW = Math.round(dispH * (texW / (float) texH));
        int px = MARGIN_X, py = MARGIN_Y;

        int visX1 = px, visX2 = px + dispW;
        if (elapsed < SWEEP_IN_MS) {
            float t = elapsed / (float) SWEEP_IN_MS;
            visX2 = px + Math.round(dispW * t);
        } else if (elapsed >= SWEEP_IN_MS + HOLD_MS) {
            long fadeElapsed = elapsed - SWEEP_IN_MS - HOLD_MS;
            float t = Math.min(1f, fadeElapsed / (float) FADE_OUT_MS);
            int shrink = Math.round((dispW / 2f) * t);
            visX1 = px + shrink;
            visX2 = px + dispW - shrink;
        }
        if (visX2 <= visX1) return;

        g.enableScissor(visX1, py, visX2, py + dispH);
        g.pose().pushMatrix();
        g.pose().translate(px, py);
        g.pose().scale(dispW / (float) texW, dispH / (float) texH);
        g.blit(RenderPipelines.GUI_TEXTURED, tex, 0, 0, 0f, 0f, texW, texH, texW, texH);
        g.pose().popMatrix();
        g.disableScissor();
    }
}
