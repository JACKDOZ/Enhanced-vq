package com.homequest.sound;

import com.homequest.HomeQuestMod;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.sounds.SoundEvent;

public class ModSounds {

    public static SoundEvent PAGE_FLIP;

    public static void initialize() {
        Identifier id = Identifier.fromNamespaceAndPath(HomeQuestMod.MOD_ID, "page_flip");
        ResourceKey<SoundEvent> key = ResourceKey.create(Registries.SOUND_EVENT, id);
        PAGE_FLIP = Registry.register(
            BuiltInRegistries.SOUND_EVENT,
            key,
            SoundEvent.createVariableRangeEvent(id)
        );

        HomeQuestMod.LOGGER.info("[Enhanced-vq] Sonido page_flip registrado.");
    }
}
