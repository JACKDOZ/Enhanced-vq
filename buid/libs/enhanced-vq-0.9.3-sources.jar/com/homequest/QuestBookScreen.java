package com.homequest;

import com.homequest.data.QuestData;
import com.homequest.network.ClaimRewardPayload;
import com.homequest.sound.ModSounds;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.ARGB;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class QuestBookScreen extends Screen {

    private static final Identifier BG = Identifier.fromNamespaceAndPath("homequest", "textures/gui/quest_book_bg.png");
    private static final int BW = 340, BH = 220;
    // Resolución nativa del PNG de fondo (recortado a su bounding box real, sin el
    // margen transparente que traía el archivo original de 1629x1150). Todo el resto
    // de constantes de este archivo (PAGE_L/PAGE_R/TAB_*) están calculadas sobre este
    // mismo sistema de coordenadas 1468x1052.
    private static final int BG_NATIVE_W = 1456, BG_NATIVE_H = 1052;

    // ── Animación de cambio de página (páginas + tapa + casita, SIN las pestañas laterales) ──
    // Calibrado usando los bordes rojos de las páginas como referencia (mucho más precisos
    // que iconos pequeños): en quest_book_bg.png (1470x1070, arte viejo) el borde IZQ iba de
    // (116,103) a (657,907) y el DER de (734,103) a (1282,906). En el gif (800x610) el borde
    // IZQ va de (28,67) a (377,585) y el DER de (428,67) a (781,585). De ahí sale la
    // transformación:
    //   bg_x = gif_x * 1.5484 + 72.64      bg_y = gif_y * 1.5511 - 1
    // NOTA (arte nuevo, quest_book_bg.png 1468x1052): se remidió el borde rojo sobre el
    // archivo nuevo y quedó prácticamente en el mismo lugar (IZQ (116,104)-(656,906),
    // DER (734,104)-(1282,906)), por eso esta transformación y el rectángulo ANIM_DEST_*
    // de abajo siguen sirviendo sin cambios.
    // Como las pestañas de colores no están en este gif, se dibuja siempre el fondo estático
    // completo primero y la animación se superpone solo sobre el rectángulo de páginas/tapa.
    private static final int ANIM_FRAME_COUNT = 6;
    private static final int ANIM_FRAME_W = 800, ANIM_FRAME_H = 610;
    private static final int ANIM_FRAME_MS = 100; // 6 frames x 100ms = 600ms
    private static final int ANIM_TOTAL_MS = ANIM_FRAME_COUNT * ANIM_FRAME_MS;
    // Rectángulo destino (en el espacio de píxeles 1470x1070 de quest_book_bg.png) donde se
    // dibuja la animación, calculado con la transformación de arriba.
    private static final float ANIM_DEST_X = 73f;
    private static final float ANIM_DEST_Y = -1f;
    private static final float ANIM_DEST_W = 1239f;
    private static final float ANIM_DEST_H = 946f;
    private static final Identifier[] ANIM_FRAMES = new Identifier[ANIM_FRAME_COUNT];
    static {
        for (int i = 0; i < ANIM_FRAME_COUNT; i++) {
            ANIM_FRAMES[i] = Identifier.fromNamespaceAndPath("homequest",
                "textures/gui/book_flip/frame_" + i + ".png");
        }
    }
    // ── Logo animado (manzana dorada encantada) para la pestaña "Logros" ──
    // Recortado del gif que se usó como referencia: 8 frames con el brillo de
    // encantamiento recorriendo la manzana. Se cicla en loop continuo (no está atado
    // a tabAnimStart, es puramente decorativo sobre la pestaña rosa).
    private static final int LOGO_FRAME_COUNT = 8;
    // Rotada 20° a la derecha (sentido horario) respecto del gif original; el recorte
    // a bounding box después de rotar da estas dimensiones (antes 265x280).
    private static final int LOGO_FRAME_W = 271, LOGO_FRAME_H = 309;
    private static final int LOGO_FRAME_MS = 120; // 8 frames x 120ms = 960ms por loop
    private static final Identifier[] LOGO_FRAMES = new Identifier[LOGO_FRAME_COUNT];
    static {
        for (int i = 0; i < LOGO_FRAME_COUNT; i++) {
            LOGO_FRAMES[i] = Identifier.fromNamespaceAndPath("homequest",
                "textures/gui/achievement_logo/frame_" + i + ".png");
        }
    }
    // ── Ícono estático del botón creeper (arriba izq., pestaña Completadas) ──
    // Antes venía dibujado en el arte de fondo; en el arte nuevo ya no, así que ahora
    // se dibuja por código como un ícono más. Aparece con una animación de "saliendo
    // de abajo de la página" cada vez que se pasa de página (ver ANIM_TOTAL_MS más
    // arriba) — el gif original no incluía este ícono en sus frames, así que en vez de
    // rehacer esa animación completa se le da una entrada propia, más simple.
    private static final int CREEPER_ICON_W = 38, CREEPER_ICON_H = 39;
    private static final int CREEPER_ICON_DISPLAY_H = 8;
    // Ojo: entre la casita y donde el lomo (tapa) se vuelve sólido en todo el ancho hay
    // un hueco transparente (la casita lo "tapa" con su propio dibujo, pero un ícono
    // suelto ahí queda flotando sobre nada en vez de apoyado en la tapa). Medido en el
    // arte: la tapa es sólida recién desde y=8 (espacio 220px) en adelante — ahí es
    // donde "termina la casita por abajo" y arranca el ícono, no al revés.
    private static final int CREEPER_TOP_Y = 8;
    private static final Identifier CREEPER_ICON = Identifier.fromNamespaceAndPath("homequest", "textures/gui/tab_icons/creeper.png");
    // Revelado escalonado (NO es un slide): después de que termina el flip de página
    // (ANIM_TOTAL_MS), el creeper se muestra de a poco en pasos discretos — un pedazo
    // más grande (de arriba hacia abajo) cada paso — durante 1 segundo, como si fuera
    // saliendo de detrás de la página. Con recorte (scissor), no con transparencia real,
    // porque blit() en esta versión no tiene un overload con alpha/tint confirmado.
    private static final int CREEPER_REVEAL_STEPS = 6;
    private static final long CREEPER_REVEAL_MS = 1000;

    // ── Ícono animado del libro encantado (pestaña "Mago") ──
    private static final int ENCH_BOOK_FRAME_COUNT = 32, ENCH_BOOK_FRAME_W = 160, ENCH_BOOK_FRAME_H = 140, ENCH_BOOK_FRAME_MS = 50;
    private static final Identifier[] ENCH_BOOK_FRAMES = new Identifier[ENCH_BOOK_FRAME_COUNT];
    static {
        for (int i = 0; i < ENCH_BOOK_FRAME_COUNT; i++)
            ENCH_BOOK_FRAMES[i] = Identifier.fromNamespaceAndPath("homequest", "textures/gui/tab_icons/enchanted_book/frame_" + i + ".png");
    }
    // Reemplaza el glifo de texto ✔/○ de antes por la carita del creeper: gris
    // mientras la misión no está completada, a color apenas se completa.
    private static final int QUEST_MARK_W = 765, QUEST_MARK_H = 764;
    private static final int QUEST_MARK_SIZE = 9; // tamaño en pantalla (mismo lugar/tamaño que el mark viejo)
    private static final Identifier QUEST_MARK_COLOR = Identifier.fromNamespaceAndPath("homequest", "textures/gui/quest_mark/creeper_color.png");
    private static final Identifier QUEST_MARK_GRAY  = Identifier.fromNamespaceAndPath("homequest", "textures/gui/quest_mark/creeper_gray.png");

    // ── Íconos animados de las 4 pestañas de categoría (arte nuevo: pestañas lisas,
    // sin ícono dibujado adentro, a diferencia del arte viejo).
    // IMPORTANTE sobre el timing: los gifs originales tenían muchísimos frames más de
    // los que conviene empaquetar (brújula: 1696 @50ms, pico: 825 @50ms). La primera
    // versión muestreaba parejo a lo largo de TODO el clip, lo que juntaba frames muy
    // lejanos entre sí (varios segundos reales de diferencia) y los reproducía rápido
    // → se veía saltado y acelerado. Ahora se usa un tramo de frames CONSECUTIVOS del
    // original (sin saltarse ninguno) con su duración real de frame, así el movimiento
    // es tan suave y a la misma velocidad que en el gif fuente. Redstone y el bloque
    // (52 y 50 frames) entraban completos sin necesidad de recortar, así que van
    // íntegros también a su velocidad original.
    private static final int COMPASS_FRAME_COUNT = 32, COMPASS_FRAME_W = 140, COMPASS_FRAME_H = 120, COMPASS_FRAME_MS = 50;
    private static final int PICKAXE_FRAME_COUNT = 32, PICKAXE_FRAME_W = 130, PICKAXE_FRAME_H = 130, PICKAXE_FRAME_MS = 50;
    private static final int BLOCK_FRAME_COUNT = 52, BLOCK_FRAME_W = 192, BLOCK_FRAME_H = 210, BLOCK_FRAME_MS = 100;
    private static final int REDSTONE_FRAME_COUNT = 50, REDSTONE_FRAME_W = 104, REDSTONE_FRAME_H = 99, REDSTONE_FRAME_MS = 60;
    private static final Identifier[] COMPASS_FRAMES = new Identifier[COMPASS_FRAME_COUNT];
    private static final Identifier[] PICKAXE_FRAMES = new Identifier[PICKAXE_FRAME_COUNT];
    private static final Identifier[] BLOCK_FRAMES = new Identifier[BLOCK_FRAME_COUNT];
    private static final Identifier[] REDSTONE_FRAMES = new Identifier[REDSTONE_FRAME_COUNT];
    static {
        for (int i = 0; i < COMPASS_FRAME_COUNT; i++)
            COMPASS_FRAMES[i] = Identifier.fromNamespaceAndPath("homequest", "textures/gui/tab_icons/compass/frame_" + i + ".png");
        for (int i = 0; i < PICKAXE_FRAME_COUNT; i++)
            PICKAXE_FRAMES[i] = Identifier.fromNamespaceAndPath("homequest", "textures/gui/tab_icons/pickaxe/frame_" + i + ".png");
        for (int i = 0; i < BLOCK_FRAME_COUNT; i++)
            BLOCK_FRAMES[i] = Identifier.fromNamespaceAndPath("homequest", "textures/gui/tab_icons/block/frame_" + i + ".png");
        for (int i = 0; i < REDSTONE_FRAME_COUNT; i++)
            REDSTONE_FRAMES[i] = Identifier.fromNamespaceAndPath("homequest", "textures/gui/tab_icons/redstone/frame_" + i + ".png");
    }
    // Momento (ms de sistema) en que empezó la animación de cambio de página; -1 = sin animación
    private long tabAnimStart = -1L;

    // ── Pestañas: coordenadas relativas a (bx, by) del libro ──
    // Recalibradas sobre el arte nuevo (quest_book_bg.png 1468x1052), midiendo
    // directamente los píxeles de cada ícono/pestaña y convirtiendo a espacio 340x220
    // con sx=340/1468, sy=220/1052.
    //
    // Principal: ahora son DOS íconos separados arriba a la izquierda (casita + creeper).
    // Casita = pestaña "Principal" de siempre. Creeper = botón nuevo, reservado para
    // contenido futuro (todavía no tiene pestaña propia, ver handleClick más abajo).
    private static final int TAB_HOME_X1 = 44,  TAB_HOME_X2 = 69;
    private static final int TAB_HOME_Y1 = 0,   TAB_HOME_Y2 = 22;
    private static final int TAB_CREEPER_X1 = 71, TAB_CREEPER_X2 = 92;
    private static final int TAB_CREEPER_Y1 = 0,  TAB_CREEPER_Y2 = 22;
    // Listón rojo que cuelga del borde inferior del libro — puramente decorativo
    // (Mago ahora tiene su propia pestaña de color, ver más abajo, así que esto ya
    // no necesita ser clickeable).
    private static final int TAB_RIBBON_X1 = 144, TAB_RIBBON_X2 = 172;
    private static final int TAB_RIBBON_Y1 = 202, TAB_RIBBON_Y2 = 219;
    // Explorador / Minero / Constructor / Técnico / Mago / Logros: 6 pestañas de color
    // ya dibujadas en la textura (verde, dorado, morado, celeste, rosa, gris). Mago
    // (libro encantado) es el anteúltimo slot; Logros (manzana) pasó a ser el último.
    // Recalibrado sobre el arte nuevo (quest_book_bg.png 1456x1052).
    private static final int TAB_X1 = 308, TAB_X2 = 333;
    private static final int[] TAB_Y1 = { 24, 50, 77, 103, 132, 160 };
    private static final int[] TAB_Y2 = { 42, 68, 95, 121, 150, 178 };
    // Slot en TAB_Y1/TAB_Y2 → valor real de selectedTab. Los primeros 4 son directos
    // (Explorador=1...Técnico=4); los últimos dos permiten que Mago quede antes que
    // Logros visualmente sin tener que renumerarla. 6 = TAB_MAGO (ver más abajo).
    private static final int[] TAB_SLOT_TO_SELECTED = { 1, 2, 3, 4, 6, 5 };
    // "Logros" (6to slot, índice 5, la gris): con el arte nuevo esta pestaña YA está
    // dibujada, así que no se rellena/bordea por código — solo se dibuja la manzana
    // encima, para no tapar el arte nuevo con un rectángulo plano.

    // Detectado píxel a píxel sobre quest_book_bg.png (arte viejo: 1470x1070 → 340x220).
    // Borde rojo IZQ: (116,103)→(657,907) | DER: (734,103)→(1282,906).
    // Con el arte nuevo (1468x1052) se volvió a medir el borde rojo y quedó prácticamente
    // en el mismo lugar (IZQ (116,104)→(656,906), DER (734,104)→(1282,906)), así que
    // PAGE_L_*/PAGE_R_* siguen valiendo sin cambios.
    // PAGE_L recalculado igual que PAGE_R: mismo ~4px de padding medido desde el marco
    // rojo de la página izquierda (que es prácticamente del mismo tamaño que el de la
    // derecha, (116,104)→(656,906)). Antes quedaba con mucho más margen que la derecha
    // sin motivo, cortando contenido de forma innecesaria.
    private static final int PAGE_L_X = 31,  PAGE_L_Y = 26, PAGE_L_W = 117, PAGE_L_H = 160;
    // PAGE_R recalculado directamente desde el marco rojo de la página derecha (con ~4px de
    // padding para no tocar el borde) — antes quedaba mucho más angosto de lo que el marco
    // realmente permite, lo que hacía que la descripción se recortara sin necesidad.
    private static final int PAGE_R_X = 174, PAGE_R_Y = 25, PAGE_R_W = 119, PAGE_R_H = 157;
    private static final int ROW_H = 12;
    // VISIBLE_ROWS: resta título (ROW_H) + fila de indicador/flecha (ROW_H)
    private static final int VISIBLE_ROWS = (PAGE_L_H - ROW_H - ROW_H) / ROW_H; // ~10

    private record QuestEntry(String id, String name, String[] desc, String[] rewards, boolean isReference) {}
    private record Tab(String label, List<QuestEntry> quests) {}

    private final List<Tab> tabs = new ArrayList<>();
    private int selectedTab  = 0;
    private int selectedIndex = -1;
    // Toggle "ocultar completadas": solo aplica a las 4 pestañas de categoría
    // (Explorador/Minero/Constructor/Técnico); no tiene sentido en Completadas
    // (que ya está pensada al revés, mostrar solo eso) ni en Logros (referencia).
    private boolean hideCompleted = false;
    // Pestaña virtual del creeper: no vive en `tabs` (no es una lista fija), se arma
    // al vuelo juntando lo completado de Explorador/Minero/Constructor/Técnico —
    // ver currentTabQuests()/buildCompletedQuests().
    private static final int TAB_MAGO = 6;      // real, vive en `tabs` (pociones + encantamientos)
    private static final int TAB_COMPLETED = 7; // virtual, no vive en `tabs`
    // Offset de scroll por tab (índice del primer elemento visible)
    private final int[] scrollOffset = new int[8]; // Principal, Explorador, Minero, Constructor, Técnico, Logros, Mago, Completadas(creeper)

    // Botones página derecha — ancho fijo, caben cómodos dentro de PAGE_R_W=119
    private int claimBtnX, claimBtnY, claimBtnW = 102, claimBtnH = 11;
    private int pinBtnX,   pinBtnY,   pinBtnW = 102,   pinBtnH = 11;
    private int optionsBtnX, optionsBtnY, optionsBtnW = 14, optionsBtnH = 12;
    private String claimBtnQuestId = null;

    // Botones de la página izquierda, en la fila del título (junto al label de la pestaña)
    private int hideToggleX, hideToggleY, hideToggleSize = 9;
    private int claimAllBtnX, claimAllBtnY, claimAllBtnW, claimAllBtnH = 9;

    // Zonas de scroll (flechas ▲▼)
    private int scrollUpBtnY, scrollDownBtnY, scrollBtnX;

    private final boolean english;

    public QuestBookScreen(boolean english) {
        super(Component.literal(english ? "Quest Book" : "Libro de Quests"));
        this.english = english;
        buildTabs();
    }

    private void buildTabs() {
        // ── PRINCIPAL ──
        List<QuestEntry> principal = new ArrayList<>();
        principal.add(q(QuestData.QUEST_FIRST_HOME, "Primera Casa", "First Home",
            new String[]{"Coloca el Cofre en tu base.", "Pon Cama, Mesa de Trabajo", "y Horno en radio de 8."},
            new String[]{"Place the Chest at your base.", "Place a Bed, Crafting Table,", "and Furnace within 8 blocks."},
            new String[]{"2x Pico de Piedra", "10x Pan", "1x Caña de Pescar"},
            new String[]{"2x Stone Pickaxe", "10x Bread", "1x Fishing Rod"}));
        principal.add(q(QuestData.QUEST_NEW_BEGINNING, "Un Nuevo Comienzo", "A New Beginning",
            new String[]{"Craftea una Mesa de Crafteo."},
            new String[]{"Craft a Crafting Table."},
            new String[]{"2x Pan"},
            new String[]{"2x Bread"}));
        principal.add(q(QuestData.QUEST_HANDS_ON, "Manos a la Obra", "Hands On",
            new String[]{"Fabrica herramientas de piedra", "de cada tipo."},
            new String[]{"Craft stone tools", "of every type."},
            new String[]{"32x Antorcha"},
            new String[]{"32x Torches"}));
        principal.add(q(QuestData.QUEST_FIRST_INGOTS, "Los Primeros Lingotes", "The First Ingots",
            new String[]{"Consigue 10 lingotes de hierro."},
            new String[]{"Get 10 iron ingots."},
            new String[]{"1x Caña de Pescar"},
            new String[]{"1x Fishing Rod"}));
        principal.add(q(QuestData.QUEST_WELL_PROTECTED, "Bien Protegido", "Well Protected",
            new String[]{"Equipa armadura completa de hierro."},
            new String[]{"Wear a full set of iron armor."},
            new String[]{"20x Zanahoria"},
            new String[]{"20x Carrots"}));
        principal.add(q(QuestData.QUEST_BEST_DEFENSE, "La Mejor Defensa", "The Best Defense",
            new String[]{"Fabrica un escudo."},
            new String[]{"Craft a shield."},
            new String[]{"16x Flechas"},
            new String[]{"16x Arrows"}));
        principal.add(q(QuestData.QUEST_FOUND_IT, "¡Lo Encontré!", "Found It!",
            new String[]{"Consigue un diamante."},
            new String[]{"Get a diamond."},
            new String[]{"32x Carbón"},
            new String[]{"32x Coal"}));
        principal.add(q(QuestData.QUEST_READY_FOR_ALL, "Listo para Todo", "Ready for Anything",
            new String[]{"Fabrica un pico de diamante."},
            new String[]{"Craft a diamond pickaxe."},
            new String[]{"32x Antorcha", "16x Bistec"},
            new String[]{"32x Torches", "16x Steak"}));
        principal.add(q(QuestData.QUEST_INTO_UNKNOWN, "Hacia lo Desconocido", "Into the Unknown",
            new String[]{"Entra al Nether."},
            new String[]{"Enter the Nether."},
            new String[]{"1x Poción"},
            new String[]{"1x Potion"}));
        principal.add(q(QuestData.QUEST_PLAYING_FIRE, "Jugando con Fuego", "Playing with Fire",
            new String[]{"Consigue 5 Blaze Rods."},
            new String[]{"Get 5 Blaze Rods."},
            new String[]{"2x Poción"},
            new String[]{"2x Potion"}));
        principal.add(q(QuestData.QUEST_BETWEEN_DIMS, "Entre Dimensiones", "Between Dimensions",
            new String[]{"Consigue 8 Ender Pearls."},
            new String[]{"Get 8 Ender Pearls."},
            new String[]{"1x Ballesta"},
            new String[]{"1x Crossbow"}));
        principal.add(q(QuestData.QUEST_ENDER_EYE, "La Mirada del Fin", "The Eye of the End",
            new String[]{"Crea un Ojo de Ender."},
            new String[]{"Craft an Eye of Ender."},
            new String[]{"4x Blaze Powder"},
            new String[]{"4x Blaze Powder"}));
        principal.add(q(QuestData.QUEST_LOST_FORTRESS, "La Fortaleza Perdida", "The Lost Fortress",
            new String[]{"Encuentra el Stronghold."},
            new String[]{"Find the Stronghold."},
            new String[]{"1x Manzana de Oro"},
            new String[]{"1x Golden Apple"}));
        principal.add(q(QuestData.QUEST_BEGINNING_END, "El Comienzo del Final", "The Beginning of the End",
            new String[]{"Derrota al Ender Dragon."},
            new String[]{"Defeat the Ender Dragon."},
            new String[]{"64x Cohetes"},
            new String[]{"64x Fireworks"}));
        principal.add(q(QuestData.QUEST_TAKE_FLIGHT, "Alza el Vuelo", "Take Flight",
            new String[]{"Consigue una Elytra."},
            new String[]{"Get an Elytra."},
            new String[]{"64x Cohetes"},
            new String[]{"64x Fireworks"}));
        principal.add(q(QuestData.QUEST_DEFYING_DARK, "Desafiando la Oscuridad", "Defying the Dark",
            new String[]{"Invoca al Wither."},
            new String[]{"Summon the Wither."},
            new String[]{"1x Tótem de la Inmortalidad"},
            new String[]{"1x Totem of Undying"}));
        principal.add(q(QuestData.QUEST_NEW_HOPE, "Una Nueva Esperanza", "A New Hope",
            new String[]{"Consigue una Nether Star."},
            new String[]{"Get a Nether Star."},
            new String[]{"1x Cabeza de Wither"},
            new String[]{"1x Wither Skeleton Skull"}));
        tabs.add(new Tab(english ? "Main" : "Principal", principal));

        // ── EXPLORADOR ──
        List<QuestEntry> explorador = new ArrayList<>();
        explorador.add(q(QuestData.QUEST_NEW_WORLD, "Un Nuevo Mundo", "A New World",
            new String[]{"Descubre un bioma nuevo."},
            new String[]{"Discover a new biome."},
            new String[]{"8x Antorcha"},
            new String[]{"8x Torches"}));
        explorador.add(q(QuestData.QUEST_BEYOND_HORIZON, "Más Allá del Horizonte", "Beyond the Horizon",
            new String[]{"Descubre 3 biomas."},
            new String[]{"Discover 3 biomes."},
            new String[]{"1x Mapa del Tesoro"},
            new String[]{"1x Treasure Map"}));
        explorador.add(q(QuestData.QUEST_NO_BORDERS, "Sin Fronteras", "No Borders",
            new String[]{"Descubre 10 biomas."},
            new String[]{"Discover 10 biomes."},
            new String[]{"1x Manzana de Oro"},
            new String[]{"1x Golden Apple"}));
        explorador.add(q(QuestData.QUEST_ALL_SEEN, "No Queda Nada por Ver", "Nothing Left to See",
            new String[]{"Descubre todos los biomas."},
            new String[]{"Discover every biome."},
            new String[]{"1x Tridente", "1x Libro Encantado"},
            new String[]{"1x Trident", "1x Enchanted Book"}));
        explorador.add(q(QuestData.QUEST_SIGNS_OF_LIFE, "Señales de Vida", "Signs of Life",
            new String[]{"Encuentra una aldea."},
            new String[]{"Find a village."},
            new String[]{"10x Papas"},
            new String[]{"10x Potatoes"}));
        explorador.add(q(QuestData.QUEST_ANCIENT_SANDS, "Arenas Antiguas", "Ancient Sands",
            new String[]{"Encuentra un templo del desierto."},
            new String[]{"Find a desert temple."},
            new String[]{"16x TNT"},
            new String[]{"16x TNT"}));
        explorador.add(q(QuestData.QUEST_JUNGLE_SECRETS, "La Selva Esconde Secretos", "The Jungle Hides Secrets",
            new String[]{"Encuentra un templo de la jungla."},
            new String[]{"Find a jungle temple."},
            new String[]{"32x Flechas"},
            new String[]{"32x Arrows"}));
        explorador.add(q(QuestData.QUEST_COLD_HOME, "Frío Hogar", "Cold Home",
            new String[]{"Encuentra un iglú."},
            new String[]{"Find an igloo."},
            new String[]{"16x Bistec"},
            new String[]{"16x Steak"}));
        explorador.add(q(QuestData.QUEST_ECHOES_PAST, "Ecos del Pasado", "Echoes of the Past",
            new String[]{"Encuentra un naufragio."},
            new String[]{"Find a shipwreck."},
            new String[]{"8x Cuero"},
            new String[]{"8x Leather"}));
        explorador.add(q(QuestData.QUEST_UNDER_WAVES, "Bajo las Olas", "Under the Waves",
            new String[]{"Encuentra ruinas oceánicas."},
            new String[]{"Find ocean ruins."},
            new String[]{"2x Poción"},
            new String[]{"2x Potion"}));
        explorador.add(q(QuestData.QUEST_SEA_KINGDOM, "El Reino del Mar", "The Kingdom of the Sea",
            new String[]{"Encuentra un monumento oceánico."},
            new String[]{"Find an ocean monument."},
            new String[]{"16x Prismarina"},
            new String[]{"16x Prismarine"}));
        explorador.add(q(QuestData.QUEST_HOSTILE_TERRITORY, "Territorio Hostil", "Hostile Territory",
            new String[]{"Encuentra un Outpost."},
            new String[]{"Find a Pillager Outpost."},
            new String[]{"32x Flechas"},
            new String[]{"32x Arrows"}));
        explorador.add(q(QuestData.QUEST_FOREST_HOUSE, "La Casa del Bosque", "The House in the Woods",
            new String[]{"Encuentra una mansión."},
            new String[]{"Find a woodland mansion."},
            new String[]{"64x Esmeraldas"},
            new String[]{"64x Emeralds"}));
        explorador.add(q(QuestData.QUEST_INFERNAL_FORTRESS, "Fortaleza Infernal", "Infernal Fortress",
            new String[]{"Encuentra una fortaleza del Nether."},
            new String[]{"Find a Nether fortress."},
            new String[]{"1x Libro Encantado"},
            new String[]{"1x Enchanted Book"}));
        explorador.add(q(QuestData.QUEST_GOLD_KINGDOM, "El Reino del Oro", "The Kingdom of Gold",
            new String[]{"Encuentra un bastión."},
            new String[]{"Find a bastion remnant."},
            new String[]{"16x Bloques de Oro"},
            new String[]{"16x Gold Blocks"}));
        explorador.add(q(QuestData.QUEST_FORGOTTEN_FORTRESS, "La Fortaleza Olvidada", "The Forgotten Fortress",
            new String[]{"Encuentra el Stronghold."},
            new String[]{"Find the Stronghold."},
            new String[]{"2x Ojos de Ender"},
            new String[]{"2x Eyes of Ender"}));
        explorador.add(q(QuestData.QUEST_STRANGE_WORLD, "Un Mundo Extraño", "A Strange World",
            new String[]{"Llega al End."},
            new String[]{"Reach the End."},
            new String[]{"32x Cohetes"},
            new String[]{"32x Fireworks"}));
        explorador.add(q(QuestData.QUEST_LOST_CITY, "La Ciudad Perdida", "The Lost City",
            new String[]{"Encuentra una End City."},
            new String[]{"Find an End City."},
            new String[]{"64x Cohetes"},
            new String[]{"64x Fireworks"}));
        explorador.add(q(QuestData.QUEST_NO_NOISE, "No Hagas Ruido", "Don't Make a Sound",
            new String[]{"Encuentra una Ancient City."},
            new String[]{"Find an Ancient City."},
            new String[]{"16x Zanahorias Doradas"},
            new String[]{"16x Golden Carrots"}));
        explorador.add(q(QuestData.QUEST_TRIAL_VALOR, "Pon a Prueba tu Valor", "Put Your Courage to the Test",
            new String[]{"Encuentra una Trial Chamber."},
            new String[]{"Find a Trial Chamber."},
            new String[]{"32x Flechas Espectrales"},
            new String[]{"32x Spectral Arrows"}));
        tabs.add(new Tab(english ? "Explorer" : "Explorador", explorador));

        // ── MINERO ──
        List<QuestEntry> minero = new ArrayList<>();
        minero.add(q(QuestData.QUEST_STAY_WARM, "No Pasaremos Frío", "Staying Warm",
            new String[]{"Consigue 10 de carbón."},
            new String[]{"Get 10 coal."},
            new String[]{"4x Chuletas de Cerdo"},
            new String[]{"4x Porkchops"}));
        minero.add(q(QuestData.QUEST_WINTER_FUEL, "Combustible para el Invierno", "Winter Fuel",
            new String[]{"Consigue 64 de carbón."},
            new String[]{"Get 64 coal."},
            new String[]{"16x Bistec"},
            new String[]{"16x Steak"}));
        minero.add(q(QuestData.QUEST_COAL_KING, "Rey del Tizón", "King of Coal",
            new String[]{"Consigue 256 de carbón."},
            new String[]{"Get 256 coal."},
            new String[]{"64x Bloques de Carbón"},
            new String[]{"64x Coal Blocks"}));
        minero.add(q(QuestData.QUEST_METAL_AGE, "Edad de los Metales", "Age of Metals",
            new String[]{"Consigue 10 hierro."},
            new String[]{"Get 10 iron."},
            new String[]{"32x Carbón"},
            new String[]{"32x Coal"}));
        minero.add(q(QuestData.QUEST_IRON_FEVER, "Fiebre del Hierro", "Iron Fever",
            new String[]{"Consigue 64 hierro."},
            new String[]{"Get 64 iron."},
            new String[]{"16x Pan"},
            new String[]{"16x Bread"}));
        minero.add(q(QuestData.QUEST_IRON_WILL, "Voluntad de Hierro", "Iron Will",
            new String[]{"Consigue 256 hierro."},
            new String[]{"Get 256 iron."},
            new String[]{"1x Libro Encantado"},
            new String[]{"1x Enchanted Book"}));
        minero.add(q(QuestData.QUEST_GOOD_CONDUCTORS, "Buenos Conductores", "Good Conductors",
            new String[]{"Consigue 10 de cobre."},
            new String[]{"Get 10 copper."},
            new String[]{"32x Tablones de Roble"},
            new String[]{"32x Oak Planks"}));
        minero.add(q(QuestData.QUEST_LIBERTY_STATUE, "Estatua de la Libertad", "Statue of Liberty",
            new String[]{"Consigue 64 de cobre."},
            new String[]{"Get 64 copper."},
            new String[]{"16x Bistec"},
            new String[]{"16x Steak"}));
        minero.add(q(QuestData.QUEST_COVETED_SHINE, "Brillo Codiciable", "Coveted Shine",
            new String[]{"Consigue 10 de oro."},
            new String[]{"Get 10 gold."},
            new String[]{"10x Lingotes de Oro"},
            new String[]{"10x Gold Ingots"}));
        minero.add(q(QuestData.QUEST_MIDAS_TOUCH, "Toque de Midas", "Midas Touch",
            new String[]{"Consigue 64 de oro."},
            new String[]{"Get 64 gold."},
            new String[]{"16x Bloques de Oro"},
            new String[]{"16x Gold Blocks"}));
        minero.add(q(QuestData.QUEST_SPARKLING_DUST, "Polvo Chispeante", "Sparkling Dust",
            new String[]{"Consigue 10 de redstone."},
            new String[]{"Get 10 redstone."},
            new String[]{"32x Redstone"},
            new String[]{"32x Redstone"}));
        minero.add(q(QuestData.QUEST_CONTINUOUS_CURRENT, "Corriente Continua", "Continuous Current",
            new String[]{"Consigue 128 de redstone."},
            new String[]{"Get 128 redstone."},
            new String[]{"16x Repetidores"},
            new String[]{"16x Repeaters"}));
        minero.add(q(QuestData.QUEST_WIZARD_DYE, "Tinte de Hechicero", "Wizard's Dye",
            new String[]{"Consigue 10 lapislázuli."},
            new String[]{"Get 10 lapis lazuli."},
            new String[]{"16x Lapislázuli"},
            new String[]{"16x Lapis Lazuli"}));
        minero.add(q(QuestData.QUEST_ULTRAMARINE, "Azul Ultramar", "Ultramarine",
            new String[]{"Consigue 64 lapislázuli."},
            new String[]{"Get 64 lapis lazuli."},
            new String[]{"1x Mesa de Encantamientos"},
            new String[]{"1x Enchanting Table"}));
        minero.add(q(QuestData.QUEST_FIVE_CHOSEN, "Los Cinco Elegidos", "The Chosen Five",
            new String[]{"Consigue 5 diamantes."},
            new String[]{"Get 5 diamonds."},
            new String[]{"1x Pico de Diamante"},
            new String[]{"1x Diamond Pickaxe"}));
        minero.add(q(QuestData.QUEST_SHINE_HOARDER, "Acaparador de Brillos", "Shine Hoarder",
            new String[]{"Consigue 32 diamantes."},
            new String[]{"Get 32 diamonds."},
            new String[]{"8x Bloques de Diamante"},
            new String[]{"8x Diamond Blocks"}));
        minero.add(q(QuestData.QUEST_UNBREAKABLE, "¡Inquebrantable!", "Unbreakable!",
            new String[]{"Consigue 64 diamantes."},
            new String[]{"Get 64 diamonds."},
            new String[]{"4x Lingotes de Netherite"},
            new String[]{"4x Netherite Ingots"}));
        minero.add(q(QuestData.QUEST_ANCIENT_ECHOES, "Ecos de la Antigüedad", "Echoes of Antiquity",
            new String[]{"Consigue 1 Ancient Debris."},
            new String[]{"Get 1 Ancient Debris."},
            new String[]{"1x Fragmento de Netherite"},
            new String[]{"1x Netherite Scrap"}));
        minero.add(q(QuestData.QUEST_FORGED_HELL, "Forjado en el Infierno", "Forged in Hell",
            new String[]{"Consigue 8 Ancient Debris."},
            new String[]{"Get 8 Ancient Debris."},
            new String[]{"1x Lingote de Netherite"},
            new String[]{"1x Netherite Ingot"}));
        minero.add(q(QuestData.QUEST_VILLAGER_FAVOR, "El Favor del Aldeano", "The Villager's Favor",
            new String[]{"Consigue una esmeralda."},
            new String[]{"Get an emerald."},
            new String[]{"5x Esmeraldas"},
            new String[]{"5x Emeralds"}));
        tabs.add(new Tab(english ? "Miner" : "Minero", minero));

        // ── CONSTRUCTOR ──
        List<QuestEntry> constructor = new ArrayList<>();
        constructor.add(q(QuestData.QUEST_HONEST_WORK, "Es Trabajo Honesto", "Honest Work",
            new String[]{"Coloca 50 bloques."},
            new String[]{"Place 50 blocks."},
            new String[]{"64x Tablones de Roble"},
            new String[]{"64x Oak Planks"}));
        constructor.add(q(QuestData.QUEST_FIRM_FOUNDATIONS, "Cimientos Firmes", "Firm Foundations",
            new String[]{"Coloca 250 bloques."},
            new String[]{"Place 250 blocks."},
            new String[]{"64x Piedra"},
            new String[]{"64x Stone"}));
        constructor.add(q(QuestData.QUEST_MASON_HANDS, "Manos de Albañil", "Mason's Hands",
            new String[]{"Coloca 1000 bloques."},
            new String[]{"Place 1,000 blocks."},
            new String[]{"32x Lingotes de Hierro"},
            new String[]{"32x Iron Ingots"}));
        constructor.add(q(QuestData.QUEST_GREAT_ARCHITECT, "Gran Arquitecto", "Great Architect",
            new String[]{"Coloca 5000 bloques."},
            new String[]{"Place 5,000 blocks."},
            new String[]{"5x Diamantes", "1x Lingote de Netherite"},
            new String[]{"5x Diamonds", "1x Netherite Ingot"}));
        constructor.add(q(QuestData.QUEST_STEP_BY_STEP, "Paso a Paso", "Step by Step",
            new String[]{"Coloca 10 escaleras."},
            new String[]{"Place 10 stairs."},
            new String[]{"32x Escaleras de Roble"},
            new String[]{"32x Oak Stairs"}));
        constructor.add(q(QuestData.QUEST_HALF_BLOCK, "A Medio Bloque", "Halfway There",
            new String[]{"Coloca 10 losas."},
            new String[]{"Place 10 slabs."},
            new String[]{"32x Losas de Roble"},
            new String[]{"32x Oak Slabs"}));
        constructor.add(q(QuestData.QUEST_ESCAPE_HATCH, "Escotilla de Escape", "Escape Hatch",
            new String[]{"Coloca 10 trapdoors."},
            new String[]{"Place 10 trapdoors."},
            new String[]{"16x Trampillas de Roble"},
            new String[]{"16x Oak Trapdoors"}));
        constructor.add(q(QuestData.QUEST_KNOCK_BEFORE, "Toca Antes de Entrar", "Knock Before Entering",
            new String[]{"Coloca 10 puertas."},
            new String[]{"Place 10 doors."},
            new String[]{"16x Puertas de Roble"},
            new String[]{"16x Oak Doors"}));
        constructor.add(q(QuestData.QUEST_FRAGILE_TRANSP, "Frágil Transparencia", "Fragile Transparency",
            new String[]{"Coloca 20 cristales."},
            new String[]{"Place 20 panes of glass."},
            new String[]{"32x Vidrio"},
            new String[]{"32x Glass"}));
        constructor.add(q(QuestData.QUEST_NO_PASS, "¡No Pasarán!", "They Shall Not Pass!",
            new String[]{"Coloca 20 vallas."},
            new String[]{"Place 20 fences."},
            new String[]{"32x Vallas de Roble"},
            new String[]{"32x Oak Fences"}));
        constructor.add(q(QuestData.QUEST_SAFE_NIGHTS, "Noches Seguras", "Safe Nights",
            new String[]{"Coloca 10 faroles."},
            new String[]{"Place 10 lanterns."},
            new String[]{"16x Faroles"},
            new String[]{"16x Lanterns"}));
        constructor.add(q(QuestData.QUEST_MARINE_LIGHT, "Iluminación Marina", "Marine Lighting",
            new String[]{"Coloca 10 linternas."},
            new String[]{"Place 10 sea lanterns."},
            new String[]{"16x Linternas Marinas"},
            new String[]{"16x Sea Lanterns"}));
        constructor.add(q(QuestData.QUEST_DETAILS_MATTER, "Detalles que Suman", "Details Matter",
            new String[]{"Coloca 20 bloques decorativos."},
            new String[]{"Place 20 decorative blocks."},
            new String[]{"8x Macetas"},
            new String[]{"8x Flower Pots"}));
        constructor.add(q(QuestData.QUEST_CHISEL_STONE, "Cincel y Piedra", "Chisel and Stone",
            new String[]{"Coloca 20 bloques tallados."},
            new String[]{"Place 20 chiseled blocks."},
            new String[]{"32x Ladrillos de Piedra Cincelados"},
            new String[]{"32x Chiseled Stone Bricks"}));
        constructor.add(q(QuestData.QUEST_PIG_HOUSE, "Casita de Cerdito", "Piggy's Little House",
            new String[]{"Coloca 20 bloques de ladrillo."},
            new String[]{"Place 20 brick blocks."},
            new String[]{"64x Ladrillos"},
            new String[]{"64x Bricks"}));
        constructor.add(q(QuestData.QUEST_CLASSIC_TEMPLE, "Templo Clásico", "Classic Temple",
            new String[]{"Coloca 20 bloques de cuarzo."},
            new String[]{"Place 20 quartz blocks."},
            new String[]{"32x Bloques de Cuarzo"},
            new String[]{"32x Quartz Blocks"}));
        constructor.add(q(QuestData.QUEST_COLOR_PALETTE, "Paleta de Colores", "Color Palette",
            new String[]{"Coloca 20 hormigón."},
            new String[]{"Place 20 concrete blocks."},
            new String[]{"8x Esmeraldas"},
            new String[]{"8x Emeralds"}));
        constructor.add(q(QuestData.QUEST_STICKY_STRUCT, "Estructuras Pegajosas", "Sticky Structures",
            new String[]{"Coloca 20 bloques de miel."},
            new String[]{"Place 20 honey blocks."},
            new String[]{"16x Bloques de Miel"},
            new String[]{"16x Honey Blocks"}));
        constructor.add(q(QuestData.QUEST_PLAZA_MEETING, "¡Reunión en la Plaza!", "Town Square Meeting!",
            new String[]{"Coloca una campana."},
            new String[]{"Place a bell."},
            new String[]{"16x Esmeraldas"},
            new String[]{"16x Emeralds"}));
        constructor.add(q(QuestData.QUEST_BEACON_LIGHT, "Luz Guía del Infinito", "Guiding Light of the Infinite",
            new String[]{"Coloca un beacon."},
            new String[]{"Place a beacon."},
            new String[]{"2x Lingotes de Netherite", "4x Bloques de Diamante"},
            new String[]{"2x Netherite Ingots", "4x Diamond Blocks"}));
        tabs.add(new Tab(english ? "Builder" : "Constructor", constructor));

        // ── TÉCNICO ──
        List<QuestEntry> tecnico = new ArrayList<>();
        tecnico.add(q(QuestData.QUEST_MOVEMENT_START, "Empieza el Movimiento", "The Movement Begins",
            new String[]{"Craftea un pistón."},
            new String[]{"Craft a piston."},
            new String[]{"4x Pistones"},
            new String[]{"4x Pistons"}));
        tecnico.add(q(QuestData.QUEST_STICKY_MECH, "Mecanismo Adhesivo", "Sticky Mechanism",
            new String[]{"Craftea un pistón pegajoso."},
            new String[]{"Craft a sticky piston."},
            new String[]{"4x Pistones Pegajosos"},
            new String[]{"4x Sticky Pistons"}));
        tecnico.add(q(QuestData.QUEST_SIGNAL_PATIENCE, "Paciencia en la Señal", "Patience in the Signal",
            new String[]{"Craftea un repetidor."},
            new String[]{"Craft a repeater."},
            new String[]{"8x Repetidores"},
            new String[]{"8x Repeaters"}));
        tecnico.add(q(QuestData.QUEST_BINARY_LOGIC, "Lógica Binaria", "Binary Logic",
            new String[]{"Craftea un comparador."},
            new String[]{"Craft a comparator."},
            new String[]{"8x Comparadores"},
            new String[]{"8x Comparators"}));
        tecnico.add(q(QuestData.QUEST_BRUTE_FORCE, "Fuerza Bruta", "Brute Force",
            new String[]{"Coloca 10 pistones."},
            new String[]{"Place 10 pistons."},
            new String[]{"32x Antorchas de Redstone"},
            new String[]{"32x Redstone Torches"}));
        tecnico.add(q(QuestData.QUEST_BACK_FORTH, "Ida y Vuelta", "Back and Forth",
            new String[]{"Coloca 10 pistones pegajosos."},
            new String[]{"Place 10 sticky pistons."},
            new String[]{"16x Bolas de Slime"},
            new String[]{"16x Slime Balls"}));
        tecnico.add(q(QuestData.QUEST_CONTROLLED_DELAY, "Retardo Controlado", "Controlled Delay",
            new String[]{"Coloca 20 repetidores."},
            new String[]{"Place 20 repeaters."},
            new String[]{"16x Repetidores"},
            new String[]{"16x Repeaters"}));
        tecnico.add(q(QuestData.QUEST_REDSTONE_BRAIN, "Cerebro de Redstone", "Redstone Brain",
            new String[]{"Coloca 20 comparadores."},
            new String[]{"Place 20 comparators."},
            new String[]{"16x Comparadores"},
            new String[]{"16x Comparators"}));
        tecnico.add(q(QuestData.QUEST_AUTO_LOGISTICS, "Logística Automatizada", "Automated Logistics",
            new String[]{"Coloca 20 tolvas."},
            new String[]{"Place 20 hoppers."},
            new String[]{"8x Tolvas"},
            new String[]{"8x Hoppers"}));
        tecnico.add(q(QuestData.QUEST_FIRE_AT_WILL, "Fuego a Discreción", "Fire at Will",
            new String[]{"Coloca 10 dispensadores."},
            new String[]{"Place 10 dispensers."},
            new String[]{"64x Flechas"},
            new String[]{"64x Arrows"}));
        tecnico.add(q(QuestData.QUEST_DROP_GOODS, "¡Suelten la Mercancía!", "Drop the Goods!",
            new String[]{"Coloca 10 soltadores."},
            new String[]{"Place 10 droppers."},
            new String[]{"4x Cofres"},
            new String[]{"4x Chests"}));
        tecnico.add(q(QuestData.QUEST_EYES_WALLS, "Ojos en las Paredes", "Eyes on the Walls",
            new String[]{"Coloca 10 observadores."},
            new String[]{"Place 10 observers."},
            new String[]{"4x Observadores"},
            new String[]{"4x Observers"}));
        tecnico.add(q(QuestData.QUEST_MANUAL_CTRL, "Control Manual", "Manual Control",
            new String[]{"Coloca 20 palancas."},
            new String[]{"Place 20 levers."},
            new String[]{"16x Palancas"},
            new String[]{"16x Levers"}));
        tecnico.add(q(QuestData.QUEST_DONT_PRESS, "¡No Toques Ese Botón!", "Don't Touch That Button!",
            new String[]{"Coloca 20 botones."},
            new String[]{"Place 20 buttons."},
            new String[]{"16x Botones de Roble"},
            new String[]{"16x Oak Buttons"}));
        tecnico.add(q(QuestData.QUEST_UNDER_FEET, "Bajo tus Pies", "Under Your Feet",
            new String[]{"Coloca 20 placas de presión."},
            new String[]{"Place 20 pressure plates."},
            new String[]{"16x Placas de Presión de Roble"},
            new String[]{"16x Oak Pressure Plates"}));
        tecnico.add(q(QuestData.QUEST_INDUSTRIAL_SAFETY, "Seguridad Industrial", "Industrial Safety",
            new String[]{"Coloca 20 trampillas de hierro."},
            new String[]{"Place 20 iron trapdoors."},
            new String[]{"8x Trampillas de Hierro"},
            new String[]{"8x Iron Trapdoors"}));
        tecnico.add(q(QuestData.QUEST_PERPETUAL_MOTION, "Movimiento Perpetuo", "Perpetual Motion",
            new String[]{"Activa un pistón 100 veces."},
            new String[]{"Activate a piston 100 times."},
            new String[]{"8x Bloques de Redstone"},
            new String[]{"8x Redstone Blocks"}));
        tecnico.add(q(QuestData.QUEST_SMART_DIST, "Distribución Inteligente", "Smart Distribution",
            new String[]{"Transporta objetos con tolvas."},
            new String[]{"Move items using hoppers."},
            new String[]{"16x Tolvas"},
            new String[]{"16x Hoppers"}));
        tecnico.add(q(QuestData.QUEST_TIC_TAC, "Tic Tac Infinito", "Infinite Tic-Tock",
            new String[]{"Construye un reloj de redstone."},
            new String[]{"Build a redstone clock."},
            new String[]{"1x Reloj"},
            new String[]{"1x Clock"}));
        tecnico.add(q(QuestData.QUEST_END_HARD_WORK, "El Fin del Trabajo Duro", "The End of Hard Work",
            new String[]{"Construye una granja automática."},
            new String[]{"Build an automatic farm."},
            new String[]{"8x Diamantes", "1x Libro Encantado"},
            new String[]{"8x Diamonds", "1x Enchanted Book"}));
        tabs.add(new Tab(english ? "Engineer" : "Técnico", tecnico));

        List<QuestEntry> logros = new ArrayList<>();
        logros.add(qi("ach_story_root", "Minecraft", "Minecraft", "Ten una mesa de trabajo en el inventario.", "Have a crafting table in the inventory."));
        logros.add(qi("ach_story_mine_stone", "Edad de Piedra", "Stone Age", "Mina piedra con tu nuevo pico.", "Mine stone with your new pickaxe."));
        logros.add(qi("ach_story_upgrade_tools", "Consiguiendo una Mejora", "Getting an Upgrade", "Construye un pico mejor.", "Construct a better pickaxe."));
        logros.add(qi("ach_story_smelt_iron", "Adquiere Ferretería", "Acquire Hardware", "Funde un lingote de hierro.", "Smelt an iron ingot."));
        logros.add(qi("ach_story_obtain_armor", "Vístete", "Suit Up", "Protégete con una pieza de armadura de hierro.", "Protect yourself with a piece of iron armor."));
        logros.add(qi("ach_story_lava_bucket", "Cosa Caliente", "Hot Stuff", "Llena un balde con lava.", "Fill a bucket with lava."));
        logros.add(qi("ach_story_iron_tools", "¿No es un Pico de Hierro?", "Isn't It Iron Pick", "Mejora tu pico.", "Upgrade your pickaxe."));
        logros.add(qi("ach_story_deflect_arrow", "Hoy No, Gracias", "Not Today, Thank You", "Desvía un proyectil con un escudo.", "Deflect a projectile with a shield."));
        logros.add(qi("ach_story_form_obsidian", "El Reto del Balde de Hielo", "Ice Bucket Challenge", "Consigue un bloque de obsidiana.", "Obtain a block of obsidian."));
        logros.add(qi("ach_story_mine_diamond", "¡Diamantes!", "Diamonds!", "Consigue diamantes.", "Acquire diamonds."));
        logros.add(qi("ach_story_enter_the_nether", "Necesitamos Ir Más Profundo", "We Need to Go Deeper", "Construye, enciende y entra a un Portal del Nether.", "Build, light and enter a Nether Portal."));
        logros.add(qi("ach_story_shiny_gear", "Cúbreme de Diamantes", "Cover Me with Diamonds", "La armadura de diamante salva vidas.", "Diamond armor saves lives."));
        logros.add(qi("ach_story_enchant_item", "Encantador", "Enchanter", "Encanta un objeto en una Mesa de Encantamientos.", "Enchant an item at an Enchanting Table."));
        logros.add(qi("ach_story_cure_zombie_villager", "Doctor Zombie", "Zombie Doctor", "Debilita y luego cura a un Aldeano Zombi.", "Weaken and then cure a Zombie Villager."));
        logros.add(qi("ach_story_follow_ender_eye", "Ojo Espía", "Eye Spy", "Sigue un Ojo de Ender hasta un Stronghold.", "Follow an Eye of Ender into a Stronghold."));
        logros.add(qi("ach_story_enter_the_end", "¿El Fin?", "The End?", "Entra al Portal del Fin.", "Enter the End Portal."));
        logros.add(qi("ach_nether_root", "Nether", "Nether", "Entra al Nether.", "Enter the Nether."));
        logros.add(qi("ach_nether_return_to_sender", "Devolver al Remitente", "Return to Sender", "Destruye un Ghast con una bola de fuego desviada.", "Destroy a Ghast with a deflected fireball."));
        logros.add(qi("ach_nether_find_bastion", "Aquellos Fueron Buenos Tiempos", "Those Were the Days", "Entra a un Bastión en Ruinas.", "Enter a Bastion Remnant."));
        logros.add(qi("ach_nether_obtain_ancient_debris", "Escondido en las Profundidades", "Hidden in the Depths", "Consigue Ancient Debris.", "Obtain Ancient Debris."));
        logros.add(qi("ach_nether_fast_travel", "Burbuja del Subespacio", "Subspace Bubble", "Usa el Nether para viajar 7 km en la Superficie.", "Use the Nether to travel 7 km in the Overworld."));
        logros.add(qi("ach_nether_find_fortress", "Una Fortaleza Terrible", "A Terrible Fortress", "Ábrete paso hasta una Fortaleza del Nether.", "Break your way into a Nether Fortress."));
        logros.add(qi("ach_nether_obtain_crying_obsidian", "¿Quién Está Cortando Cebollas?", "Who is Cutting Onions?", "Consigue Obsidiana Llorona.", "Obtain Crying Obsidian."));
        logros.add(qi("ach_nether_distract_piglin", "Oh, Brillante", "Oh Shiny", "Distrae a los Piglins con oro.", "Distract Piglins with gold."));
        logros.add(qi("ach_nether_ride_strider", "Este Bote Tiene Patas", "This Boat Has Legs", "Monta un Strider con un Hongo Distorsionado en un Palo.", "Ride a Strider with a Warped Fungus on a Stick."));
        logros.add(qi("ach_nether_uneasy_alliance", "Alianza Incómoda", "Uneasy Alliance", "Rescata a un Ghast del Nether, llévalo sano y salvo a la Superficie... y luego mátalo.", "Rescue a Ghast from the Nether, bring it safely home to the Overworld... and then kill it."));
        logros.add(qi("ach_nether_loot_bastion", "Cerdos de Guerra", "War Pigs", "Saquea un cofre en un Bastión en Ruinas.", "Loot a chest in a Bastion Remnant."));
        logros.add(qi("ach_nether_netherite_armor", "Cúbreme de Escombros", "Cover Me in Debris", "Consigue un set completo de armadura de Netherite.", "Get a full suit of Netherite armor."));
        logros.add(qi("ach_nether_get_wither_skull", "Esqueleto Espeluznante", "Spooky Scary Skeleton", "Consigue una calavera de Esqueleto Wither.", "Obtain a Wither Skeleton's skull."));
        logros.add(qi("ach_nether_obtain_blaze_rod", "Hacia el Fuego", "Into Fire", "Quítale su vara a un Blaze.", "Relieve a Blaze of its rod."));
        logros.add(qi("ach_nether_charge_respawn_anchor", "No Tan \"Nueve\" Vidas", "Not Quite \"Nine\" Lives", "Carga un Ancla de Reaparición al máximo.", "Charge a Respawn Anchor to the maximum."));
        logros.add(qi("ach_nether_ride_strider_in_overworld_lava", "Se Siente Como Casa", "Feels Like Home", "Da un paseo largo en Strider sobre un lago de lava en la Superficie.", "Take a Strider for a loooong ride on a lava lake in the Overworld."));
        logros.add(qi("ach_nether_explore_nether", "Destinos Turísticos Calientes", "Hot Tourist Destinations", "Explora todos los biomas del Nether.", "Explore all Nether biomes."));
        logros.add(qi("ach_nether_summon_wither", "Cumbres del Wither", "Withering Heights", "Invoca al Wither.", "Summon the Wither."));
        logros.add(qi("ach_nether_brew_potion", "Cervecería Local", "Local Brewery", "Prepara una poción.", "Brew a potion."));
        logros.add(qi("ach_nether_create_beacon", "Trae el Faro a Casa", "Bring Home the Beacon", "Construye y coloca un Faro.", "Construct and place a Beacon."));
        logros.add(qi("ach_nether_all_potions", "Un Cóctel Furioso", "A Furious Cocktail", "Ten todos los efectos de poción aplicados al mismo tiempo.", "Have every potion effect applied at the same time."));
        logros.add(qi("ach_nether_create_full_beacon", "El Faronator", "Beaconator", "Lleva un Faro a su máximo poder.", "Bring a Beacon to full power."));
        logros.add(qi("ach_nether_all_effects", "¿Cómo Llegamos Aquí? (oculto)", "How Did We Get Here? (oculto)", "Ten todos los efectos aplicados al mismo tiempo.", "Have every effect applied at the same time."));
        logros.add(qi("ach_end_root", "El Fin", "The End", "Entra al Fin.", "Enter the End."));
        logros.add(qi("ach_end_kill_dragon", "Libera el Fin", "Free the End", "Mata al Dragón del Fin.", "Kill the Ender Dragon."));
        logros.add(qi("ach_end_dragon_egg", "La Próxima Generación", "The Next Generation", "Sostén el Huevo de Dragón.", "Hold the Dragon Egg."));
        logros.add(qi("ach_end_enter_end_gateway", "Escapada Remota", "Remote Getaway", "Entra a un Portal del Fin (Gateway).", "Enter an End Gateway."));
        logros.add(qi("ach_end_respawn_dragon", "El Fin... Otra Vez...", "The End... Again...", "Vuelve a invocar al Dragón del Fin.", "Respawn the Ender Dragon."));
        logros.add(qi("ach_end_dragon_breath", "Necesitas una Menta", "You Need a Mint", "Recoge Aliento de Dragón en una botella de vidrio.", "Collect Dragon's Breath in a glass bottle."));
        logros.add(qi("ach_end_find_end_city", "La Ciudad al Final del Juego", "The City at the End of the Game", "Entra a una Ciudad del Fin.", "Enter an End City."));
        logros.add(qi("ach_end_elytra", "El Cielo es el Límite", "Sky's the Limit", "Encuentra unos Élitros.", "Find an Elytra."));
        logros.add(qi("ach_end_levitate", "Gran Vista Desde Aquí Arriba", "Great View From Up Here", "Levita 50 bloques por el ataque de un Shulker.", "Levitate up 50 blocks from a Shulker's attack."));
        logros.add(qi("ach_adventure_root", "Aventura", "Adventure", "Aventura, exploración y combate.", "Adventure, exploration and combat."));
        logros.add(qi("ach_adventure_voluntary_exile", "Exilio Voluntario (oculto)", "Voluntary Exile (oculto)", "Mata a un capitán de asalto.", "Kill a raid captain."));
        logros.add(qi("ach_adventure_kill_a_mob", "Cazador de Monstruos", "Monster Hunter", "Mata a cualquier monstruo hostil.", "Kill any hostile monster."));
        logros.add(qi("ach_adventure_trade", "¡Qué Buen Trato!", "What a Deal!", "Comercia exitosamente con un Aldeano.", "Successfully trade with a Villager."));
        logros.add(qi("ach_adventure_honey_block_slide", "Situación Pegajosa", "Sticky Situation", "Salta a un Bloque de Miel para amortiguar tu caída.", "Jump into a Honey Block to break your fall."));
        logros.add(qi("ach_adventure_ol_betsy", "La Vieja Betsy", "Ol' Betsy", "Dispara una Ballesta.", "Shoot a Crossbow."));
        logros.add(qi("ach_adventure_sleep_in_bed", "Dulces Sueños", "Sweet Dreams", "Duerme en una Cama para cambiar tu punto de reaparición.", "Sleep in a Bed to change your respawn point."));
        logros.add(qi("ach_adventure_hero_of_the_village", "Héroe de la Aldea (oculto)", "Hero of the Village (oculto)", "Defiende con éxito una aldea de un asalto.", "Successfully defend a village from a raid."));
        logros.add(qi("ach_adventure_throw_trident", "Un Chiste Desechable", "A Throwaway Joke", "Lanza un Tridente a algo.", "Throw a Trident at something."));
        logros.add(qi("ach_adventure_shoot_arrow", "Apunta Bien", "Take Aim", "Dispárale a algo con una Flecha.", "Shoot something with an Arrow."));
        logros.add(qi("ach_adventure_kill_all_mobs", "Monstruos Cazados", "Monsters Hunted", "Mata a cada tipo de monstruo hostil.", "Kill one of every hostile monster."));
        logros.add(qi("ach_adventure_totem_of_undying", "Postmortal", "Postmortal", "Usa un Tótem de la Inmortalidad para engañar a la muerte.", "Use a Totem of Undying to cheat death."));
        logros.add(qi("ach_adventure_summon_iron_golem", "Ayuda Contratada", "Hired Help", "Invoca un Gólem de Hierro para ayudar a defender una aldea.", "Summon an Iron Golem to help defend a village."));
        logros.add(qi("ach_adventure_two_birds_one_arrow", "Dos Pájaros de un Tiro", "Two Birds, One Arrow", "Mata a dos Phantoms con una flecha perforante.", "Kill two Phantoms with a piercing Arrow."));
        logros.add(qi("ach_adventure_whos_the_pillager_now", "¿Quién es el Saqueador Ahora?", "Who's the Pillager Now?", "Dale a un Pillager una cucharada de su propia medicina.", "Give a Pillager a taste of their own medicine."));
        logros.add(qi("ach_adventure_arbalistic", "Ballestero (oculto)", "Arbalistic (oculto)", "Mata a cinco criaturas distintas con un solo disparo de ballesta.", "Kill five unique mobs with one crossbow shot."));
        logros.add(qi("ach_adventure_adventuring_time", "Hora de Aventura", "Adventuring Time", "Descubre todos los biomas.", "Discover every biome."));
        logros.add(qi("ach_adventure_very_very_frightening", "Muy Muy Aterrador", "Very Very Frightening", "Golpea a un Aldeano con un rayo.", "Strike a Villager with lightning."));
        logros.add(qi("ach_adventure_sniper_duel", "Duelo de Francotiradores", "Sniper Duel", "Mata a un Esqueleto desde al menos 50 metros de distancia.", "Kill a Skeleton from at least 50 meters away."));
        logros.add(qi("ach_adventure_bullseye", "En el Blanco", "Bullseye", "Dale al centro de un bloque Diana desde al menos 30 metros.", "Hit the bullseye of a Target block from at least 30 meters away."));
        logros.add(qi("ach_husbandry_root", "Cría de Animales", "Husbandry", "Consume cualquier cosa que se pueda consumir, excepto pastel.", "Consume anything that can be consumed, except cake."));
        logros.add(qi("ach_husbandry_safely_harvest_honey", "Sé Nuestro Invitado", "Bee Our Guest", "Usa una Fogata para recolectar Miel de una Colmena con una Botella de Vidrio sin enojar a las Abejas.", "Use a Campfire to collect Honey from a Beehive with a Glass Bottle without angering the Bees."));
        logros.add(qi("ach_husbandry_breed_an_animal", "Los Loros y los Murciélagos", "The Parrots and the Bats", "Cría dos animales juntos.", "Breed two animals together."));
        logros.add(qi("ach_husbandry_allay_deliver_item_to_player", "Tienes un Amigo en Mí (oculto)", "You've Got a Friend in Me (oculto)", "Haz que un Allay te entregue objetos.", "Have an Allay deliver items to you."));
        logros.add(qi("ach_husbandry_ride_a_boat_with_a_goat", "¡Lo que Flote tu Cabra!", "Whatever Floats Your Goat!", "Súbete a un Bote y flota junto a una Cabra.", "Get in a Boat and float with a Goat."));
        logros.add(qi("ach_husbandry_tame_an_animal", "Mejores Amigos Para Siempre", "Best Friends Forever", "Doma un animal.", "Tame an animal."));
        logros.add(qi("ach_husbandry_make_a_sign_glow", "¡Que Brille!", "Glow and Behold!", "Haz que el texto de cualquier cartel brille.", "Make the text of any kind of sign glow."));
        logros.add(qi("ach_husbandry_fishy_business", "Asunto Turbio", "Fishy Business", "Pesca un pez.", "Catch a fish."));
        logros.add(qi("ach_husbandry_silk_touch_nest", "Mudanza Total de Abejas", "Total Beelocation", "Mueve un Nido de Abejas, con 3 abejas adentro, usando Toque de Seda.", "Move a Bee Nest, with 3 Bees inside, using Silk Touch."));
        logros.add(qi("ach_husbandry_tadpole_in_a_bucket", "Bukkit Bukkit", "Bukkit Bukkit", "Atrapa un Renacuajo en un Balde.", "Catch a Tadpole in a Bucket."));
        logros.add(qi("ach_husbandry_obtain_sniffer_egg", "Huele Interesante (oculto)", "Smells Interesting (oculto)", "Consigue un Huevo de Sniffer.", "Obtain a Sniffer Egg."));
        logros.add(qi("ach_husbandry_plant_seed", "Un Lugar de Semillas", "A Seedy Place", "Planta una semilla y obsérvala crecer.", "Plant a seed and watch it grow."));
        logros.add(qi("ach_husbandry_wax_on", "Encerar", "Wax On", "Aplica un Panal a un bloque de Cobre.", "Apply Honeycomb to a Copper block."));
        logros.add(qi("ach_husbandry_bred_all_animals", "De Dos en Dos", "Two by Two", "¡Cría a todos los animales!", "Breed all the animals!"));
        logros.add(qi("ach_husbandry_allay_deliver_cake_to_note_block", "Canción de Cumpleaños (oculto)", "Birthday Song (oculto)", "Haz que un Allay deje un Pastel en un Bloque de Notas.", "Have an Allay drop a Cake at a Note Block."));
        logros.add(qi("ach_husbandry_complete_catalogue", "Un Catálogo Completo", "A Complete Catalogue", "Doma todas las variantes de Gato.", "Tame all Cat variants."));
        logros.add(qi("ach_husbandry_tactical_fishing", "Pesca Táctica", "Tactical Fishing", "Atrapa un pez... ¡sin caña de pescar!", "Catch a fish... without a Fishing Rod!"));
        logros.add(qi("ach_husbandry_leash_all_frog_variants", "Cuando el Escuadrón Llega a la Ciudad", "When the Squad Hops into Town", "Pon una correa a cada variante de Rana.", "Get each Frog variant on a Lead."));
        logros.add(qi("ach_husbandry_feed_snifflet", "Pequeños Snifflets (oculto)", "Little Sniffs (oculto)", "Alimenta a un Snifflet.", "Feed a Snifflet."));
        logros.add(qi("ach_husbandry_balanced_diet", "Una Dieta Balanceada", "A Balanced Diet", "Come todo lo que sea comestible, aunque no te haga bien.", "Eat everything that is edible, even if it's not good for you."));
        logros.add(qi("ach_husbandry_obtain_netherite_hoe", "Dedicación Seria", "Serious Dedication", "Usa un Lingote de Netherite para mejorar una Azada.", "Use a Netherite Ingot to upgrade a Hoe."));
        logros.add(qi("ach_husbandry_wax_off", "Desencerar", "Wax Off", "Raspa la cera de un bloque de Cobre.", "Scrape Wax off of a Copper block."));
        logros.add(qi("ach_husbandry_axolotl_in_a_bucket", "El Depredador Más Tierno", "The Cutest Predator", "Atrapa un Ajolote en un Balde.", "Catch an Axolotl in a Bucket."));
        logros.add(qi("ach_husbandry_froglights", "¡Nuestros Poderes Combinados!", "With Our Powers Combined!", "Ten todos los tipos de Luz de Rana en tu inventario.", "Have all Froglights in your inventory."));
        logros.add(qi("ach_husbandry_plant_any_sniffer_seed", "Plantando el Pasado (oculto)", "Planting the Past (oculto)", "Planta cualquier semilla de Sniffer.", "Plant any Sniffer seed."));
        logros.add(qi("ach_husbandry_kill_axolotl_target", "¡El Poder Curativo de la Amistad!", "The Healing Power of Friendship!", "Haz equipo con un Ajolote y gana una pelea.", "Team up with an Axolotl and win a fight."));
        logros.add(qi("ach_husbandry_repair_wolf_armor", "Como Nueva", "Good as New", "Repara una Armadura de Lobo dañada usando Escamas de Armadillo.", "Repair a damaged Wolf Armor using Armadillo Scutes."));
        logros.add(qi("ach_husbandry_whole_pack", "La Manada Completa", "The Whole Pack", "Doma una de cada variante de Lobo.", "Tame one of each Wolf variant."));
        logros.add(qi("ach_husbandry_remove_wolf_armor", "Pura Brillantez", "Shear Brilliance", "Quítale la Armadura a un Lobo usando Tijeras.", "Remove Wolf Armor from a Wolf using Shears."));
        tabs.add(new Tab(english ? "Achievements" : "Logros", logros));

        // "Mago": pociones + encantamientos. Vacía por ahora — el diseño completo de
        // misiones llega después; mientras tanto la pestaña ya está viva (ícono, click,
        // tooltip) y muestra el mismo "Próximamente..." que cualquier lista vacía.
        List<QuestEntry> mago = new ArrayList<>();
        mago.add(q(QuestData.QUEST_MAGO_BREWING_STAND, "Alambique", "Brewing Stand",
            new String[]{"Consigue una Mesa de Pociones."},
            new String[]{"Get a Brewing Stand."},
            new String[]{"8x Botella de Vidrio"},
            new String[]{"8x Glass Bottle"}));
        mago.add(q(QuestData.QUEST_KNOWLEDGE, "El Poder del Conocimiento", "The Power of Knowledge",
            new String[]{"Fabrica una mesa de encantamientos."},
            new String[]{"Craft an enchanting table."},
            new String[]{"16x Libros"},
            new String[]{"16x Books"}));
        mago.add(q(QuestData.QUEST_MAGO_POTION_AWKWARD, "Poción Incierta", "Awkward Potion",
            new String[]{"Prepara una Poción Incierta."},
            new String[]{"Brew an Awkward Potion."},
            new String[]{"4x Verruga del Nether"},
            new String[]{"4x Nether Wart"}));
        mago.add(q(QuestData.QUEST_MAGO_POTION_SWIFTNESS, "Poción de Velocidad", "Potion of Swiftness",
            new String[]{"Prepara una Poción de Velocidad."},
            new String[]{"Brew a Potion of Swiftness."},
            new String[]{"2x Poción"},
            new String[]{"2x Potion"}));
        mago.add(q(QuestData.QUEST_MAGO_POTION_POISON, "Poción de Veneno", "Potion of Poison",
            new String[]{"Prepara una Poción de Veneno."},
            new String[]{"Brew a Potion of Poison."},
            new String[]{"2x Poción"},
            new String[]{"2x Potion"}));
        mago.add(q(QuestData.QUEST_MAGO_POTION_WEAKNESS, "Poción de Debilidad", "Potion of Weakness",
            new String[]{"Prepara una Poción de Debilidad."},
            new String[]{"Brew a Potion of Weakness."},
            new String[]{"2x Poción"},
            new String[]{"2x Potion"}));
        mago.add(q(QuestData.QUEST_MAGO_POTION_SLOWNESS, "Poción de Lentitud", "Potion of Slowness",
            new String[]{"Prepara una Poción de Lentitud."},
            new String[]{"Brew a Potion of Slowness."},
            new String[]{"2x Poción"},
            new String[]{"2x Potion"}));
        mago.add(q(QuestData.QUEST_MAGO_POTION_FIRE_RESISTANCE, "Poción de Resistencia al Fuego", "Potion of Fire Resistance",
            new String[]{"Prepara una Poción de", "Resistencia al Fuego."},
            new String[]{"Brew a Potion of", "Fire Resistance."},
            new String[]{"2x Poción", "2x Magma Cream"},
            new String[]{"2x Potion", "2x Magma Cream"}));
        mago.add(q(QuestData.QUEST_MAGO_POTION_HEALING, "Poción de Curación", "Potion of Healing",
            new String[]{"Prepara una Poción de Curación."},
            new String[]{"Brew a Potion of Healing."},
            new String[]{"2x Poción"},
            new String[]{"2x Potion"}));
        mago.add(q(QuestData.QUEST_MAGO_POTION_HARMING, "Poción de Daño", "Potion of Harming",
            new String[]{"Prepara una Poción de Daño."},
            new String[]{"Brew a Potion of Harming."},
            new String[]{"2x Poción"},
            new String[]{"2x Potion"}));
        mago.add(q(QuestData.QUEST_MAGO_POTION_LEAPING, "Poción de Salto", "Potion of Leaping",
            new String[]{"Prepara una Poción de Salto."},
            new String[]{"Brew a Potion of Leaping."},
            new String[]{"2x Poción"},
            new String[]{"2x Potion"}));
        mago.add(q(QuestData.QUEST_MAGO_POTION_STRENGTH, "Poción de Fuerza", "Potion of Strength",
            new String[]{"Prepara una Poción de Fuerza."},
            new String[]{"Brew a Potion of Strength."},
            new String[]{"3x Poción", "4x Blaze Powder"},
            new String[]{"3x Potion", "4x Blaze Powder"}));
        mago.add(q(QuestData.QUEST_MAGO_POTION_REGENERATION, "Poción de Regeneración", "Potion of Regeneration",
            new String[]{"Prepara una Poción de Regeneración."},
            new String[]{"Brew a Potion of Regeneration."},
            new String[]{"3x Poción", "2x Lágrima de Ghast"},
            new String[]{"3x Potion", "2x Ghast Tear"}));
        mago.add(q(QuestData.QUEST_MAGO_POTION_NIGHT_VISION, "Poción de Visión Nocturna", "Potion of Night Vision",
            new String[]{"Prepara una Poción de Visión Nocturna."},
            new String[]{"Brew a Potion of Night Vision."},
            new String[]{"3x Poción"},
            new String[]{"3x Potion"}));
        mago.add(q(QuestData.QUEST_MAGO_POTION_WATER_BREATHING, "Poción de Respiración Acuática", "Potion of Water Breathing",
            new String[]{"Prepara una Poción de", "Respiración Acuática."},
            new String[]{"Brew a Potion of", "Water Breathing."},
            new String[]{"3x Poción"},
            new String[]{"3x Potion"}));
        mago.add(q(QuestData.QUEST_MAGO_POTION_INVISIBILITY, "Poción de Invisibilidad", "Potion of Invisibility",
            new String[]{"Prepara una Poción de Invisibilidad."},
            new String[]{"Brew a Potion of Invisibility."},
            new String[]{"1x Libro Encantado", "3x Poción"},
            new String[]{"1x Enchanted Book", "3x Potion"}));
        mago.add(q(QuestData.QUEST_MAGO_POTION_SLOW_FALLING, "Poción de Caída Lenta", "Potion of Slow Falling",
            new String[]{"Prepara una Poción de Caída Lenta."},
            new String[]{"Brew a Potion of Slow Falling."},
            new String[]{"1x Libro Encantado", "3x Poción"},
            new String[]{"1x Enchanted Book", "3x Potion"}));
        mago.add(q(QuestData.QUEST_MAGO_POTION_TURTLE_MASTER, "Poción del Maestro Tortuga", "Potion of the Turtle Master",
            new String[]{"Prepara una Poción del Maestro Tortuga."},
            new String[]{"Brew a Potion of the Turtle Master."},
            new String[]{"1x Libro Encantado", "4x Lapislázuli", "3x Poción"},
            new String[]{"1x Enchanted Book", "4x Lapis Lazuli", "3x Potion"}));
        mago.add(q(QuestData.QUEST_MAGO_ENCH_SHARPNESS, "Encantamiento: Filo", "Enchantment: Sharpness",
            new String[]{"Encanta un objeto con Filo."},
            new String[]{"Enchant an item with Sharpness."},
            new String[]{"2x Estanterías"},
            new String[]{"2x Bookshelves"}));
        mago.add(q(QuestData.QUEST_MAGO_ENCH_SMITE, "Encantamiento: Aspecto Rabioso", "Enchantment: Smite",
            new String[]{"Encanta un objeto con Aspecto Rabioso."},
            new String[]{"Enchant an item with Smite."},
            new String[]{"2x Estanterías"},
            new String[]{"2x Bookshelves"}));
        mago.add(q(QuestData.QUEST_MAGO_ENCH_BANE_ARTHROPODS, "Encantamiento: Perjuicio", "Enchantment: Bane of Arthropods",
            new String[]{"Encanta un objeto con Perjuicio."},
            new String[]{"Enchant an item with Bane of Arthropods."},
            new String[]{"2x Estanterías"},
            new String[]{"2x Bookshelves"}));
        mago.add(q(QuestData.QUEST_MAGO_ENCH_FIRE_ASPECT, "Encantamiento: Aspecto de Fuego", "Enchantment: Fire Aspect",
            new String[]{"Encanta un objeto con Aspecto de Fuego."},
            new String[]{"Enchant an item with Fire Aspect."},
            new String[]{"4x Libros"},
            new String[]{"4x Books"}));
        mago.add(q(QuestData.QUEST_MAGO_ENCH_KNOCKBACK, "Encantamiento: Retroceso", "Enchantment: Knockback",
            new String[]{"Encanta un objeto con Retroceso."},
            new String[]{"Enchant an item with Knockback."},
            new String[]{"4x Libros"},
            new String[]{"4x Books"}));
        mago.add(q(QuestData.QUEST_MAGO_ENCH_LOOTING, "Encantamiento: Botín", "Enchantment: Looting",
            new String[]{"Encanta un objeto con Botín."},
            new String[]{"Enchant an item with Looting."},
            new String[]{"2x Estanterías"},
            new String[]{"2x Bookshelves"}));
        mago.add(q(QuestData.QUEST_MAGO_ENCH_SWEEPING_EDGE, "Encantamiento: Filo Arrasador", "Enchantment: Sweeping Edge",
            new String[]{"Encanta un objeto con Filo Arrasador."},
            new String[]{"Enchant an item with Sweeping Edge."},
            new String[]{"1x Libro Encantado", "4x Lapislázuli"},
            new String[]{"1x Enchanted Book", "4x Lapis Lazuli"}));
        mago.add(q(QuestData.QUEST_MAGO_ENCH_BREACH, "Encantamiento: Brecha", "Enchantment: Breach",
            new String[]{"Encanta un objeto con Brecha."},
            new String[]{"Enchant an item with Breach."},
            new String[]{"1x Libro Encantado", "8x Lapislázuli"},
            new String[]{"1x Enchanted Book", "8x Lapis Lazuli"}));
        mago.add(q(QuestData.QUEST_MAGO_ENCH_DENSITY, "Encantamiento: Densidad", "Enchantment: Density",
            new String[]{"Encanta un objeto con Densidad."},
            new String[]{"Enchant an item with Density."},
            new String[]{"1x Libro Encantado", "8x Lapislázuli"},
            new String[]{"1x Enchanted Book", "8x Lapis Lazuli"}));
        mago.add(q(QuestData.QUEST_MAGO_ENCH_WIND_BURST, "Encantamiento: Ráfaga de Viento", "Enchantment: Wind Burst",
            new String[]{"Encanta un objeto con Ráfaga de Viento."},
            new String[]{"Enchant an item with Wind Burst."},
            new String[]{"1x Libro Encantado", "8x Lapislázuli"},
            new String[]{"1x Enchanted Book", "8x Lapis Lazuli"}));
        mago.add(q(QuestData.QUEST_MAGO_ENCH_LUNGE, "Encantamiento: Embestida", "Enchantment: Lunge",
            new String[]{"Encanta un objeto con Embestida."},
            new String[]{"Enchant an item with Lunge."},
            new String[]{"1x Libro Encantado", "8x Lapislázuli"},
            new String[]{"1x Enchanted Book", "8x Lapis Lazuli"}));
        mago.add(q(QuestData.QUEST_MAGO_ENCH_POWER, "Encantamiento: Poder", "Enchantment: Power",
            new String[]{"Encanta un objeto con Poder."},
            new String[]{"Enchant an item with Power."},
            new String[]{"2x Estanterías"},
            new String[]{"2x Bookshelves"}));
        mago.add(q(QuestData.QUEST_MAGO_ENCH_PUNCH, "Encantamiento: Empuje", "Enchantment: Punch",
            new String[]{"Encanta un objeto con Empuje."},
            new String[]{"Enchant an item with Punch."},
            new String[]{"4x Libros"},
            new String[]{"4x Books"}));
        mago.add(q(QuestData.QUEST_MAGO_ENCH_FLAME, "Encantamiento: Llama", "Enchantment: Flame",
            new String[]{"Encanta un objeto con Llama."},
            new String[]{"Enchant an item with Flame."},
            new String[]{"4x Libros"},
            new String[]{"4x Books"}));
        mago.add(q(QuestData.QUEST_MAGO_ENCH_INFINITY, "Encantamiento: Infinidad", "Enchantment: Infinity",
            new String[]{"Encanta un objeto con Infinidad."},
            new String[]{"Enchant an item with Infinity."},
            new String[]{"2x Estanterías"},
            new String[]{"2x Bookshelves"}));
        mago.add(q(QuestData.QUEST_MAGO_ENCH_MULTISHOT, "Encantamiento: Multidisparo", "Enchantment: Multishot",
            new String[]{"Encanta un objeto con Multidisparo."},
            new String[]{"Enchant an item with Multishot."},
            new String[]{"2x Estanterías"},
            new String[]{"2x Bookshelves"}));
        mago.add(q(QuestData.QUEST_MAGO_ENCH_PIERCING, "Encantamiento: Perforación", "Enchantment: Piercing",
            new String[]{"Encanta un objeto con Perforación."},
            new String[]{"Enchant an item with Piercing."},
            new String[]{"4x Libros"},
            new String[]{"4x Books"}));
        mago.add(q(QuestData.QUEST_MAGO_ENCH_QUICK_CHARGE, "Encantamiento: Carga Rápida", "Enchantment: Quick Charge",
            new String[]{"Encanta un objeto con Carga Rápida."},
            new String[]{"Enchant an item with Quick Charge."},
            new String[]{"4x Libros"},
            new String[]{"4x Books"}));
        mago.add(q(QuestData.QUEST_MAGO_ENCH_CHANNELING, "Encantamiento: Canalización", "Enchantment: Channeling",
            new String[]{"Encanta un objeto con Canalización."},
            new String[]{"Enchant an item with Channeling."},
            new String[]{"1x Libro Encantado", "8x Lapislázuli"},
            new String[]{"1x Enchanted Book", "8x Lapis Lazuli"}));
        mago.add(q(QuestData.QUEST_MAGO_ENCH_IMPALING, "Encantamiento: Impaler", "Enchantment: Impaling",
            new String[]{"Encanta un objeto con Impaler."},
            new String[]{"Enchant an item with Impaling."},
            new String[]{"1x Libro Encantado", "4x Lapislázuli"},
            new String[]{"1x Enchanted Book", "4x Lapis Lazuli"}));
        mago.add(q(QuestData.QUEST_MAGO_ENCH_LOYALTY, "Encantamiento: Lealtad", "Enchantment: Loyalty",
            new String[]{"Encanta un objeto con Lealtad."},
            new String[]{"Enchant an item with Loyalty."},
            new String[]{"2x Estanterías"},
            new String[]{"2x Bookshelves"}));
        mago.add(q(QuestData.QUEST_MAGO_ENCH_RIPTIDE, "Encantamiento: Marejada", "Enchantment: Riptide",
            new String[]{"Encanta un objeto con Marejada."},
            new String[]{"Enchant an item with Riptide."},
            new String[]{"1x Libro Encantado", "4x Lapislázuli"},
            new String[]{"1x Enchanted Book", "4x Lapis Lazuli"}));
        mago.add(q(QuestData.QUEST_MAGO_ENCH_EFFICIENCY, "Encantamiento: Eficiencia", "Enchantment: Efficiency",
            new String[]{"Encanta un objeto con Eficiencia."},
            new String[]{"Enchant an item with Efficiency."},
            new String[]{"2x Estanterías"},
            new String[]{"2x Bookshelves"}));
        mago.add(q(QuestData.QUEST_MAGO_ENCH_FORTUNE, "Encantamiento: Fortuna", "Enchantment: Fortune",
            new String[]{"Encanta un objeto con Fortuna."},
            new String[]{"Enchant an item with Fortune."},
            new String[]{"1x Libro Encantado", "4x Lapislázuli"},
            new String[]{"1x Enchanted Book", "4x Lapis Lazuli"}));
        mago.add(q(QuestData.QUEST_MAGO_ENCH_SILK_TOUCH, "Encantamiento: Toque de Seda", "Enchantment: Silk Touch",
            new String[]{"Encanta un objeto con Toque de Seda."},
            new String[]{"Enchant an item with Silk Touch."},
            new String[]{"1x Libro Encantado", "4x Lapislázuli"},
            new String[]{"1x Enchanted Book", "4x Lapis Lazuli"}));
        mago.add(q(QuestData.QUEST_MAGO_ENCH_UNBREAKING, "Encantamiento: Reparación", "Enchantment: Unbreaking",
            new String[]{"Encanta un objeto con Reparación."},
            new String[]{"Enchant an item with Unbreaking."},
            new String[]{"2x Estanterías"},
            new String[]{"2x Bookshelves"}));
        mago.add(q(QuestData.QUEST_MAGO_ENCH_MENDING, "Encantamiento: Mantenimiento", "Enchantment: Mending",
            new String[]{"Encanta un objeto con Mantenimiento."},
            new String[]{"Enchant an item with Mending."},
            new String[]{"1x Libro Encantado", "8x Lapislázuli"},
            new String[]{"1x Enchanted Book", "8x Lapis Lazuli"}));
        mago.add(q(QuestData.QUEST_MAGO_ENCH_LUCK_OF_THE_SEA, "Encantamiento: Suerte Marina", "Enchantment: Luck of the Sea",
            new String[]{"Encanta un objeto con Suerte Marina."},
            new String[]{"Enchant an item with Luck of the Sea."},
            new String[]{"4x Libros"},
            new String[]{"4x Books"}));
        mago.add(q(QuestData.QUEST_MAGO_ENCH_LURE, "Encantamiento: Señuelo", "Enchantment: Lure",
            new String[]{"Encanta un objeto con Señuelo."},
            new String[]{"Enchant an item with Lure."},
            new String[]{"4x Libros"},
            new String[]{"4x Books"}));
        mago.add(q(QuestData.QUEST_MAGO_ENCH_PROTECTION, "Encantamiento: Protección", "Enchantment: Protection",
            new String[]{"Encanta un objeto con Protección."},
            new String[]{"Enchant an item with Protection."},
            new String[]{"2x Estanterías"},
            new String[]{"2x Bookshelves"}));
        mago.add(q(QuestData.QUEST_MAGO_ENCH_FIRE_PROTECTION, "Encantamiento: Protección contra el Fuego", "Enchantment: Fire Protection",
            new String[]{"Encanta un objeto con Protección contra el Fuego."},
            new String[]{"Enchant an item with Fire Protection."},
            new String[]{"2x Estanterías"},
            new String[]{"2x Bookshelves"}));
        mago.add(q(QuestData.QUEST_MAGO_ENCH_BLAST_PROTECTION, "Encantamiento: Protección contra Explosiones", "Enchantment: Blast Protection",
            new String[]{"Encanta un objeto con Protección contra Explosiones."},
            new String[]{"Enchant an item with Blast Protection."},
            new String[]{"2x Estanterías"},
            new String[]{"2x Bookshelves"}));
        mago.add(q(QuestData.QUEST_MAGO_ENCH_PROJECTILE_PROTECTION, "Encantamiento: Protección contra Proyectiles", "Enchantment: Projectile Protection",
            new String[]{"Encanta un objeto con Protección contra Proyectiles."},
            new String[]{"Enchant an item with Projectile Protection."},
            new String[]{"2x Estanterías"},
            new String[]{"2x Bookshelves"}));
        mago.add(q(QuestData.QUEST_MAGO_ENCH_FEATHER_FALLING, "Encantamiento: Plumas", "Enchantment: Feather Falling",
            new String[]{"Encanta un objeto con Plumas."},
            new String[]{"Enchant an item with Feather Falling."},
            new String[]{"4x Libros"},
            new String[]{"4x Books"}));
        mago.add(q(QuestData.QUEST_MAGO_ENCH_DEPTH_STRIDER, "Encantamiento: Paso Ágil", "Enchantment: Depth Strider",
            new String[]{"Encanta un objeto con Paso Ágil."},
            new String[]{"Enchant an item with Depth Strider."},
            new String[]{"4x Libros"},
            new String[]{"4x Books"}));
        mago.add(q(QuestData.QUEST_MAGO_ENCH_FROST_WALKER, "Encantamiento: Paso Helado", "Enchantment: Frost Walker",
            new String[]{"Encanta un objeto con Paso Helado."},
            new String[]{"Enchant an item with Frost Walker."},
            new String[]{"1x Libro Encantado", "8x Lapislázuli"},
            new String[]{"1x Enchanted Book", "8x Lapis Lazuli"}));
        mago.add(q(QuestData.QUEST_MAGO_ENCH_SOUL_SPEED, "Encantamiento: Velocidad de Alma", "Enchantment: Soul Speed",
            new String[]{"Encanta un objeto con Velocidad de Alma."},
            new String[]{"Enchant an item with Soul Speed."},
            new String[]{"1x Botas de Diamante Encantadas", "(Velocidad de Alma III)"},
            new String[]{"1x Enchanted Diamond Boots", "(Soul Speed III)"}));
        mago.add(q(QuestData.QUEST_MAGO_ENCH_SWIFT_SNEAK, "Encantamiento: Sigilo Veloz", "Enchantment: Swift Sneak",
            new String[]{"Encanta un objeto con Sigilo Veloz."},
            new String[]{"Enchant an item with Swift Sneak."},
            new String[]{"1x Grebas de Diamante Encantadas", "(Sigilo Veloz III)"},
            new String[]{"1x Enchanted Diamond Leggings", "(Swift Sneak III)"}));
        mago.add(q(QuestData.QUEST_MAGO_ENCH_AQUA_AFFINITY, "Encantamiento: Afinidad Acuática", "Enchantment: Aqua Affinity",
            new String[]{"Encanta un objeto con Afinidad Acuática."},
            new String[]{"Enchant an item with Aqua Affinity."},
            new String[]{"4x Libros"},
            new String[]{"4x Books"}));
        mago.add(q(QuestData.QUEST_MAGO_ENCH_RESPIRATION, "Encantamiento: Respiración", "Enchantment: Respiration",
            new String[]{"Encanta un objeto con Respiración."},
            new String[]{"Enchant an item with Respiration."},
            new String[]{"4x Libros"},
            new String[]{"4x Books"}));
        mago.add(q(QuestData.QUEST_MAGO_ENCH_THORNS, "Encantamiento: Espinas", "Enchantment: Thorns",
            new String[]{"Encanta un objeto con Espinas."},
            new String[]{"Enchant an item with Thorns."},
            new String[]{"4x Libros"},
            new String[]{"4x Books"}));
        mago.add(q(QuestData.QUEST_MAGO_GEAR_ARMOR_PIECE, "Encantador Novato", "Novice Enchanter",
            new String[]{"Encanta 1 pieza de armadura."},
            new String[]{"Enchant 1 piece of armor."},
            new String[]{"4x Lapislázuli", "2x Libros"},
            new String[]{"4x Lapis Lazuli", "2x Books"}));
        mago.add(q(QuestData.QUEST_MAGO_GEAR_ARMOR_FULL, "Blindaje Completo", "Full Plate",
            new String[]{"Encanta un set completo de armadura", "(casco, pecho, piernas y botas)."},
            new String[]{"Enchant a full set of armor", "(helmet, chestplate, leggings, boots)."},
            new String[]{"1x Peto de Diamante Encantado", "(Protección IV) + 8x Lapislázuli"},
            new String[]{"1x Enchanted Diamond Chestplate", "(Protection IV) + 8x Lapis Lazuli"}));
        mago.add(q(QuestData.QUEST_MAGO_GEAR_PICKAXE, "Pico Encantado", "Enchanted Pickaxe",
            new String[]{"Encanta un pico."},
            new String[]{"Enchant a pickaxe."},
            new String[]{"1x Pico de Diamante Encantado", "(Eficiencia IV)"},
            new String[]{"1x Enchanted Diamond Pickaxe", "(Efficiency IV)"}));
        mago.add(q(QuestData.QUEST_MAGO_GEAR_SWORD, "Espada Encantada", "Enchanted Sword",
            new String[]{"Encanta una espada."},
            new String[]{"Enchant a sword."},
            new String[]{"1x Espada de Diamante Encantada", "(Filo IV)"},
            new String[]{"1x Enchanted Diamond Sword", "(Sharpness IV)"}));
        mago.add(q(QuestData.QUEST_MAGO_GEAR_AXE, "Hacha Encantada", "Enchanted Axe",
            new String[]{"Encanta un hacha."},
            new String[]{"Enchant an axe."},
            new String[]{"1x Hacha de Diamante Encantada", "(Eficiencia IV)"},
            new String[]{"1x Enchanted Diamond Axe", "(Efficiency IV)"}));
        tabs.add(new Tab(english ? "Mage" : "Mago", mago));
    }

    private QuestEntry q(String id, String nameEs, String nameEn,
                          String[] descEs, String[] descEn,
                          String[] rewardsEs, String[] rewardsEn) {
        return english
            ? new QuestEntry(id, nameEn, descEn, rewardsEn, false)
            : new QuestEntry(id, nameEs, descEs, rewardsEs, false);
    }

    // Logros oficiales de Minecraft: solo de referencia (informativos), sin
    // recompensa del mod ni botón de "Obtener" — este mod no los otorga,
    // los otorga el propio juego.
    private QuestEntry qi(String id, String nameEs, String nameEn,
                          String descEs, String descEn) {
        return english
            ? new QuestEntry(id, nameEn, new String[]{ descEn }, new String[0], true)
            : new QuestEntry(id, nameEs, new String[]{ descEs }, new String[0], true);
    }

    // ── Pestaña "Completadas" (creeper) ──
    // No es una lista fija como las demás: se arma cada vez que se necesita, juntando
    // las misiones completadas de Explorador/Minero/Constructor/Técnico/Mago (se ignoran
    // Principal y Logros — Logros son solo de referencia, sin recompensa/canje).
    // Orden pedido: las completadas y AÚN NO canjeadas van agrupadas arriba; las ya
    // canjeadas quedan abajo. Como el estado de canje puede cambiar en cualquier
    // momento (el jugador reclama una recompensa), se recalcula en cada acceso en vez
    // de guardarse una vez — es una operación barata (unas pocas docenas de misiones).
    // Índices en `tabs` que dan recompensa canjeable (todas menos Principal/Logros).
    private static final int[] REWARD_TAB_INDICES = { 1, 2, 3, 4, TAB_MAGO };

    private List<QuestEntry> unclaimedCompletedQuests() {
        Minecraft mc = Minecraft.getInstance();
        UUID uuid = mc.player != null ? mc.player.getUUID() : null;
        List<QuestEntry> result = new ArrayList<>();
        if (uuid != null) {
            for (int t : REWARD_TAB_INDICES) {
                for (QuestEntry q : tabs.get(t).quests()) {
                    if (QuestData.get().isCompleted(uuid, q.id()) && !QuestData.get().isClaimed(uuid, q.id())) {
                        result.add(q);
                    }
                }
            }
        }
        return result;
    }

    private List<QuestEntry> claimedCompletedQuests() {
        Minecraft mc = Minecraft.getInstance();
        UUID uuid = mc.player != null ? mc.player.getUUID() : null;
        List<QuestEntry> result = new ArrayList<>();
        if (uuid != null) {
            for (int t : REWARD_TAB_INDICES) {
                for (QuestEntry q : tabs.get(t).quests()) {
                    if (QuestData.get().isCompleted(uuid, q.id()) && QuestData.get().isClaimed(uuid, q.id())) {
                        result.add(q);
                    }
                }
            }
        }
        return result;
    }

    private List<QuestEntry> buildCompletedQuests() {
        List<QuestEntry> result = new ArrayList<>();
        result.addAll(unclaimedCompletedQuests());
        result.addAll(claimedCompletedQuests());
        return result;
    }

    private static boolean isCategoryTab(int tab) { return (tab >= 1 && tab <= 4) || tab == TAB_MAGO; }

    private List<QuestEntry> currentTabQuests() {
        if (selectedTab == TAB_COMPLETED) return buildCompletedQuests();
        List<QuestEntry> base = tabs.get(selectedTab).quests();
        if (!hideCompleted || !isCategoryTab(selectedTab)) return base;
        Minecraft mc = Minecraft.getInstance();
        UUID uuid = mc.player != null ? mc.player.getUUID() : null;
        if (uuid == null) return base;
        List<QuestEntry> filtered = new ArrayList<>();
        for (QuestEntry q : base) {
            if (!QuestData.get().isCompleted(uuid, q.id())) filtered.add(q);
        }
        return filtered;
    }

    private String currentTabLabel() {
        return selectedTab == TAB_COMPLETED ? (english ? "Completed" : "Completadas") : tabs.get(selectedTab).label();
    }

    // ── Scroll ──
    private int maxScroll() {
        List<QuestEntry> quests = currentTabQuests();
        return Math.max(0, quests.size() - VISIBLE_ROWS);
    }

    private void scrollUp()   { if (scrollOffset[selectedTab] > 0)          scrollOffset[selectedTab]--; }
    private void scrollDown() { if (scrollOffset[selectedTab] < maxScroll()) scrollOffset[selectedTab]++; }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        super.extractRenderState(g, mouseX, mouseY, delta);

        int bx = this.width  / 2 - BW / 2;
        int by = this.height / 2 - BH / 2;

        // Fondo escalado (siempre se dibuja completo: incluye pestañas de colores, que no
        // forman parte de la animación de cambio de página)
        float scaleX = (float) BW / BG_NATIVE_W;
        float scaleY = (float) BH / BG_NATIVE_H;
        g.pose().pushMatrix();
        g.pose().translate(bx, by);
        g.pose().scale(scaleX, scaleY);
        g.blit(RenderPipelines.GUI_TEXTURED, BG, 0, 0, 0f, 0f, BG_NATIVE_W, BG_NATIVE_H, BG_NATIVE_W, BG_NATIVE_H);
        g.pose().popMatrix();

        // ── Animación de cambio de página ──
        // Se superpone encima del fondo, alineada con el rectángulo de páginas/tapa
        // (ver constantes ANIM_DEST_*). Las pestañas de colores quedan visibles debajo
        // porque la animación no las cubre.
        long now = System.currentTimeMillis();
        boolean pageFlipping = tabAnimStart >= 0 && (now - tabAnimStart) < ANIM_TOTAL_MS;
        // Después de que termina el flip (600ms), el creeper se revela en pasos discretos
        // durante 1 segundo más — no es parte del gif de flip, así que se anima aparte.
        boolean creeperRevealing = tabAnimStart >= 0
            && (now - tabAnimStart) >= ANIM_TOTAL_MS
            && (now - tabAnimStart) < ANIM_TOTAL_MS + CREEPER_REVEAL_MS;

        if (pageFlipping) {
            int frameIdx = (int) ((now - tabAnimStart) / ANIM_FRAME_MS);
            if (frameIdx >= ANIM_FRAME_COUNT) frameIdx = ANIM_FRAME_COUNT - 1;

            float animScaleX = ANIM_DEST_W / ANIM_FRAME_W;
            float animScaleY = ANIM_DEST_H / ANIM_FRAME_H;
            g.pose().pushMatrix();
            g.pose().translate(bx, by);
            g.pose().scale(scaleX, scaleY);
            g.pose().translate(ANIM_DEST_X, ANIM_DEST_Y);
            g.pose().scale(animScaleX, animScaleY);
            g.blit(RenderPipelines.GUI_TEXTURED, ANIM_FRAMES[frameIdx], 0, 0, 0f, 0f,
                ANIM_FRAME_W, ANIM_FRAME_H, ANIM_FRAME_W, ANIM_FRAME_H);
            g.pose().popMatrix();

            // Mientras se reproduce la animación no se dibuja el contenido de la página
            // ni se dejan zonas de click activas (evita clicks fantasma sobre botones viejos).
            // El creeper tampoco se dibuja todavía — recién empieza a aparecer cuando esto termina.
            pinBtnY = 9999; claimBtnY = 9999; claimBtnQuestId = null;
            scrollUpBtnY = 9999; scrollDownBtnY = 9999;
            hideToggleY = 9999; claimAllBtnY = 9999;
            return;
        }
        if (!creeperRevealing) {
            tabAnimStart = -1L;
        }

        // Botón creeper (arriba izq., junto a la casita): pestaña "Completadas".
        // El ícono en sí (creeper.png) se dibuja siempre en su posición de descanso;
        // el resalte + tooltip solo al pasar el mouse, igual que las demás pestañas.
        // Justo después de pasar de página, se revela de a poco en 6 pasos (1 segundo
        // en total) en vez de aparecer todo de una — como si fuera saliendo de detrás
        // de la página, un pedacito más visible en cada paso.
        {
            int crX1 = bx + TAB_CREEPER_X1, crX2 = bx + TAB_CREEPER_X2;
            int crY1 = by + TAB_CREEPER_Y1, crY2 = by + TAB_CREEPER_Y2;
            boolean overCreeper = mouseX >= crX1 && mouseX <= crX2 && mouseY >= crY1 && mouseY <= crY2;
            if (overCreeper) {
                g.fill(crX1, crY1, crX2, crY2, 0x33FFFFFF);
            }
            int revealStep = CREEPER_REVEAL_STEPS;
            if (creeperRevealing) {
                long revealElapsed = now - tabAnimStart - ANIM_TOTAL_MS;
                revealStep = (int) (revealElapsed / (CREEPER_REVEAL_MS / CREEPER_REVEAL_STEPS)) + 1;
                revealStep = Math.min(revealStep, CREEPER_REVEAL_STEPS);
            }
            drawCreeperIcon(g, bx, by, revealStep, CREEPER_REVEAL_STEPS);
            if (overCreeper) {
                int pending = unclaimedCompletedQuests().size();
                String tip = (english ? "Completed" : "Completadas")
                    + (pending > 0 ? " (" + pending + (english ? " unclaimed)" : " sin reclamar)") : "");
                drawTooltip(g, crX1, crY2 + 2, tip);
                // el ancho puede empujar el tooltip fuera por la izquierda si es largo;
                // como este botón está pegado al borde izquierdo del libro, se ancla
                // por la izquierda (crX1) en vez de centrarlo para no cortarlo.
            }
            int hX1 = bx + TAB_HOME_X1, hX2 = bx + TAB_HOME_X2;
            int hY1 = by + TAB_HOME_Y1, hY2 = by + TAB_HOME_Y2;
            boolean overHome = mouseX >= hX1 && mouseX <= hX2 && mouseY >= hY1 && mouseY <= hY2;
            if (overHome) {
                String tip = english ? "Main" : "Principal";
                drawTooltip(g, hX1, hY2 + 2, tip);
            }
        }

        Minecraft mc = Minecraft.getInstance();
        UUID uuid = mc.player != null ? mc.player.getUUID() : null;

        // Reset botones
        pinBtnY = 9999; claimBtnY = 9999; claimBtnQuestId = null;
        hideToggleY = 9999; claimAllBtnY = 9999;

        List<QuestEntry> quests = currentTabQuests();
        int offset = scrollOffset[selectedTab];
        int visibleEnd = Math.min(quests.size(), offset + VISIBLE_ROWS);

        // ══ PÁGINA IZQUIERDA ══
        int lx = bx + PAGE_L_X;
        int ly = by + PAGE_L_Y;

        // Scissor cubre TODA el área desde el borde rojo — título incluido
        g.enableScissor(bx + PAGE_L_X, by + PAGE_L_Y,
                        bx + PAGE_L_X + PAGE_L_W, by + PAGE_L_Y + PAGE_L_H);

        // Título tab
        g.text(mc.font, Component.literal("§0§l" + currentTabLabel()),
            lx, ly, ARGB.opaque(0x3D1A00), false);

        // Toggle "ocultar completadas" — solo en las 4 categorías. Ícono a la derecha
        // del título; el tooltip (con el mismo helper que las pestañas) explica qué hace,
        // así no hace falta texto pegado que no entraría en el ancho de la página.
        if (isCategoryTab(selectedTab)) {
            hideToggleX = lx + PAGE_L_W - hideToggleSize;
            hideToggleY = ly;
            boolean overToggle = mouseX >= hideToggleX && mouseX <= hideToggleX + hideToggleSize
                               && mouseY >= hideToggleY && mouseY <= hideToggleY + hideToggleSize;
            g.fill(hideToggleX, hideToggleY, hideToggleX + hideToggleSize, hideToggleY + hideToggleSize,
                hideCompleted ? 0xFF3C8C3C : 0xFF6B6B6B);
            if (overToggle) {
                String tip = english ? "Hide completed" : "Ocultar completadas";
                int tw = mc.font.width(tip) + 4;
                drawTooltip(g, hideToggleX + hideToggleSize - tw, hideToggleY + hideToggleSize + 2, tip);
            }
        } else {
            hideToggleY = 9999;
        }

        // Botón "Reclamar todo" — solo en Completadas, y solo si hay algo pendiente.
        if (selectedTab == TAB_COMPLETED) {
            List<QuestEntry> pending = unclaimedCompletedQuests();
            if (!pending.isEmpty()) {
                String btnLabel = english ? "All" : "Todo";
                claimAllBtnW = mc.font.width(btnLabel) + 6;
                claimAllBtnX = lx + PAGE_L_W - claimAllBtnW;
                claimAllBtnY = ly;
                boolean overClaimAll = mouseX >= claimAllBtnX && mouseX <= claimAllBtnX + claimAllBtnW
                                     && mouseY >= claimAllBtnY && mouseY <= claimAllBtnY + claimAllBtnH;
                g.fill(claimAllBtnX, claimAllBtnY, claimAllBtnX + claimAllBtnW, claimAllBtnY + claimAllBtnH,
                    overClaimAll ? 0xFF3C8C3C : 0xFF2E6B2E);
                g.text(mc.font, Component.literal("§f" + btnLabel),
                    claimAllBtnX + 3, claimAllBtnY + 1, ARGB.opaque(0xFFFFFF), false);
                if (overClaimAll) {
                    String tip = english ? "Claim all pending rewards" : "Reclamar todas las recompensas pendientes";
                    int tw = mc.font.width(tip) + 4;
                    drawTooltip(g, claimAllBtnX + claimAllBtnW - tw, claimAllBtnY + claimAllBtnH + 2, tip);
                }
            } else {
                claimAllBtnY = 9999;
            }
        }
        ly += ROW_H;

        if (quests.isEmpty()) {
            String emptyMsg = selectedTab == TAB_COMPLETED
                ? (english ? "§8No completed quests yet..." : "§8Aún no completaste misiones...")
                : (english ? "§8Coming soon..." : "§8Próximamente...");
            g.text(mc.font, Component.literal(emptyMsg), lx, ly + 20, ARGB.opaque(0x555555), false);
        } else {
            for (int i = offset; i < visibleEnd; i++) {
                QuestEntry quest = quests.get(i);
                boolean done    = uuid != null && QuestData.get().isCompleted(uuid, quest.id());
                boolean sel     = i == selectedIndex;

                if (sel) g.fill(lx - 2, ly - 1, lx + PAGE_L_W - 2, ly + 12, 0x33A0600A);

                // Ticket de estado: antes era un glifo de texto (✔/○), ahora es la
                // carita del creeper — en blanco y negro mientras no está completada,
                // a color apenas se completa (mismo lugar y tamaño que el mark viejo).
                Identifier markTex = done ? QUEST_MARK_COLOR : QUEST_MARK_GRAY;
                g.pose().pushMatrix();
                g.pose().translate(lx, ly);
                g.pose().scale(QUEST_MARK_SIZE / (float) QUEST_MARK_W, QUEST_MARK_SIZE / (float) QUEST_MARK_H);
                g.blit(RenderPipelines.GUI_TEXTURED, markTex, 0, 0, 0f, 0f, QUEST_MARK_W, QUEST_MARK_H, QUEST_MARK_W, QUEST_MARK_H);
                g.pose().popMatrix();

                String label = "§0" + truncate(mc, quest.name(), PAGE_L_W - (QUEST_MARK_SIZE + 3));
                g.text(mc.font, Component.literal(label), lx + QUEST_MARK_SIZE + 2, ly, ARGB.opaque(0x3D1A00), false);
                ly += ROW_H;
            }
        }

        // Flechas y indicador en la fila reservada del fondo (no solapan con la lista)
        int bottomRowY = by + PAGE_L_Y + PAGE_L_H - ROW_H;
        scrollBtnX     = bx + PAGE_L_X + PAGE_L_W - 10;
        scrollUpBtnY   = by + PAGE_L_Y + ROW_H;       // justo bajo el título
        scrollDownBtnY = bottomRowY;                   // fila reservada

        if (offset > 0) {
            g.fill(scrollBtnX, scrollUpBtnY, scrollBtnX + 10, scrollUpBtnY + 9, 0x88000000);
            g.text(mc.font, Component.literal("§f▲"), scrollBtnX + 1, scrollUpBtnY, ARGB.opaque(0xFFFFFF), false);
        }
        if (offset < maxScroll()) {
            g.fill(scrollBtnX, scrollDownBtnY, scrollBtnX + 10, scrollDownBtnY + 9, 0x88000000);
            g.text(mc.font, Component.literal("§f▼"), scrollBtnX + 1, scrollDownBtnY, ARGB.opaque(0xFFFFFF), false);
        }

        // Indicador en la misma fila reservada, a la izquierda
        if (quests.size() > VISIBLE_ROWS) {
            String indicator = (offset + 1) + "-" + visibleEnd + "/" + quests.size();
            g.text(mc.font, Component.literal("§8" + indicator),
                lx, bottomRowY + 1, ARGB.opaque(0x555555), false);
        }

        g.disableScissor();

        // ══ PÁGINA DERECHA ══
        g.enableScissor(bx + PAGE_R_X, by + PAGE_R_Y,
                        bx + PAGE_R_X + PAGE_R_W, by + PAGE_R_Y + PAGE_R_H);

        if (selectedIndex >= 0 && selectedIndex < quests.size()) {
            QuestEntry q    = quests.get(selectedIndex);
            boolean done    = uuid != null && QuestData.get().isCompleted(uuid, q.id());
            boolean claimed = uuid != null && QuestData.get().isClaimed(uuid, q.id());
            boolean pinned  = uuid != null && q.id().equals(QuestData.get().getPinnedQuest(uuid));

            int rx = bx + PAGE_R_X;
            int ry = by + PAGE_R_Y;

            // Nombre — truncar si es muy largo en vez de partir en 2 líneas
            String nombre = truncate(mc, q.name(), PAGE_R_W);
            String nombre2 = null;
            if (mc.font.width("§0§l" + q.name()) > PAGE_R_W) {
                int split = q.name().lastIndexOf(' ', q.name().length() / 2 + 6);
                if (split > 0) {
                    nombre  = q.name().substring(0, split);
                    nombre2 = q.name().substring(split + 1);
                }
            }
            g.text(mc.font, Component.literal("§0§l" + nombre), rx, ry, ARGB.opaque(0x3D1A00), false);
            ry += 10;
            if (nombre2 != null) {
                g.text(mc.font, Component.literal("§0§l" + nombre2), rx, ry, ARGB.opaque(0x3D1A00), false);
                ry += 10;
            }

            // Estado — los logros de referencia no los rastrea este mod (los
            // otorga el propio Minecraft), así que se muestra una etiqueta
            // informativa en vez de "En progreso/Completada".
            String status = q.isReference()
                ? (english ? "§9§oOfficial Minecraft Achievement" : "§9§oLogro oficial de Minecraft")
                : (english
                    ? ((done && claimed) ? "§7Claimed" : done ? "§2Completed!" : "§6In progress...")
                    : ((done && claimed) ? "§7Reclamada" : done ? "§2¡Completada!" : "§6En progreso..."));
            g.text(mc.font, Component.literal(status), rx, ry, ARGB.opaque(0x3D1A00), false);
            ry += 12;

            // Descripción — se une todo el texto y se reparte con salto de línea real,
            // usando el ancho completo permitido por el marco rojo (PAGE_R_W).
            // Antes cada línea predefinida se truncaba con "..." si no entraba; ahora
            // el texto completo siempre es legible, sin perder palabras.
            String fullDesc = String.join(" ", q.desc());
            for (String line : wrapText(mc, fullDesc, PAGE_R_W)) {
                g.text(mc.font, Component.literal("§8" + line),
                    rx, ry, ARGB.opaque(0x5C3317), false);
                ry += 10;
            }
            ry += 4;

            // Los logros de referencia terminan acá: no tienen recompensa de
            // este mod ni botones de Obtener/Fijar (Minecraft ya los rastrea
            // en su propia pantalla de logros, con la tecla L).
            if (!q.isReference()) {
                // Recompensa
                g.text(mc.font, Component.literal(english ? "§0§lReward:" : "§0§lRecompensa:"), rx, ry, ARGB.opaque(0x3D1A00), false);
                ry += 10;
                for (String r : q.rewards()) {
                    g.text(mc.font, Component.literal("§8• " + truncate(mc, r, PAGE_R_W - 6)),
                        rx, ry, ARGB.opaque(0x5C3317), false);
                    ry += 10;
                }
                ry += 4;

                // Botón Obtener
                if (done && !claimed) {
                    claimBtnX = rx; claimBtnY = ry; claimBtnQuestId = q.id();
                    g.fill(rx, ry, rx + claimBtnW, ry + claimBtnH, 0xCC1A4A8B);
                    g.fill(rx, ry, rx + claimBtnW, ry + 1, 0xFFFFFFFF);
                    String claimTxt = english ? "§f§l[ Claim ]" : "§f§l[ Obtener ]";
                    g.text(mc.font, Component.literal(claimTxt),
                        rx + (claimBtnW - mc.font.width(claimTxt)) / 2,
                        ry + 3, ARGB.opaque(0xFFFFFF), false);
                    ry += claimBtnH + 4;
                }

                // Botón Fijar
                if (!done) {
                    pinBtnX = rx; pinBtnY = ry;
                    g.fill(rx, ry, rx + pinBtnW, ry + pinBtnH, pinned ? 0xCC6B2200 : 0xCC1A5C1A);
                    g.fill(rx, ry, rx + pinBtnW, ry + 1, 0xFFFFFFFF);
                    String btnTxt = english
                        ? (pinned ? "[ Unpin from HUD ]" : "[ Pin to HUD ]")
                        : (pinned ? "[ Desfijar HUD ]" : "[ Fijar en HUD ]");
                    g.text(mc.font, Component.literal("§f" + btnTxt),
                        rx + (pinBtnW - mc.font.width("§f" + btnTxt)) / 2,
                        ry + 3, ARGB.opaque(0xFFFFFF), false);
                }
            }
        } else if (!quests.isEmpty()) {
            int rx = bx + PAGE_R_X;
            int ry = by + PAGE_R_Y + 30;
            if (english) {
                g.text(mc.font, Component.literal("§8<- Select"), rx, ry, ARGB.opaque(0x5C3317), false);
                g.text(mc.font, Component.literal("§8a quest"),    rx, ry + 11, ARGB.opaque(0x5C3317), false);
            } else {
                g.text(mc.font, Component.literal("§8<- Selecciona"), rx, ry, ARGB.opaque(0x5C3317), false);
                g.text(mc.font, Component.literal("§8una misión"),    rx, ry + 11, ARGB.opaque(0x5C3317), false);
            }
        }

        g.disableScissor();

        // Botón de opciones (⚙) — esquina inferior derecha de la página derecha,
        // simétrico al contador de páginas de abajo a la izquierda. Coordenadas
        // ancladas a PAGE_R_X/PAGE_R_W/PAGE_R_Y/PAGE_R_H para no salirse nunca
        // del marco rojo de la página (mismo límite que usa el resto del texto
        // de esta página, ver PAGE_R_W más arriba).
        optionsBtnX = bx + PAGE_R_X + PAGE_R_W - optionsBtnW;
        optionsBtnY = by + PAGE_R_Y + PAGE_R_H - optionsBtnH;
        boolean overOptions = mouseX >= optionsBtnX && mouseX <= optionsBtnX + optionsBtnW
                            && mouseY >= optionsBtnY && mouseY <= optionsBtnY + optionsBtnH;
        g.fill(optionsBtnX, optionsBtnY, optionsBtnX + optionsBtnW, optionsBtnY + optionsBtnH,
            overOptions ? 0xAA000000 : 0x77000000);
        g.text(mc.font, Component.literal("§f⚙"),
            optionsBtnX + (optionsBtnW - mc.font.width("⚙")) / 2, optionsBtnY + 2,
            ARGB.opaque(0xFFFFFF), false);

        // Íconos animados de las 4 pestañas de categoría (Explorador/Minero/Constructor/Técnico).
        // Mismo resalte sutil de hover/selección que la pestaña de Logros, para que las 6
        // pestañas de la derecha se sientan consistentes entre sí.
        drawAnimatedTabIcon(g, bx, by, mouseX, mouseY, 0, 1, tabs.get(1).label(),
            COMPASS_FRAMES, COMPASS_FRAME_COUNT, COMPASS_FRAME_W, COMPASS_FRAME_H, COMPASS_FRAME_MS, 12);
        drawAnimatedTabIcon(g, bx, by, mouseX, mouseY, 1, 2, tabs.get(2).label(),
            PICKAXE_FRAMES, PICKAXE_FRAME_COUNT, PICKAXE_FRAME_W, PICKAXE_FRAME_H, PICKAXE_FRAME_MS, 12);
        drawAnimatedTabIcon(g, bx, by, mouseX, mouseY, 2, 3, tabs.get(3).label(),
            BLOCK_FRAMES, BLOCK_FRAME_COUNT, BLOCK_FRAME_W, BLOCK_FRAME_H, BLOCK_FRAME_MS, 12);
        drawAnimatedTabIcon(g, bx, by, mouseX, mouseY, 3, 4, tabs.get(4).label(),
            REDSTONE_FRAMES, REDSTONE_FRAME_COUNT, REDSTONE_FRAME_W, REDSTONE_FRAME_H, REDSTONE_FRAME_MS, 12);
        // Mago (libro encantado) — anteúltimo slot (índice 4), pestaña real TAB_MAGO(6).
        drawAnimatedTabIcon(g, bx, by, mouseX, mouseY, 4, TAB_MAGO, tabs.get(TAB_MAGO).label(),
            ENCH_BOOK_FRAMES, ENCH_BOOK_FRAME_COUNT, ENCH_BOOK_FRAME_W, ENCH_BOOK_FRAME_H, ENCH_BOOK_FRAME_MS, 12);

        // Pestaña "Logros" — último slot (índice 5, la gris). Con el arte nuevo esta
        // pestaña YA está dibujada en la textura, así que ya no se rellena ni se le
        // dibuja un borde por código (antes sí, porque el arte vieja solo traía 4
        // pestañas). Se deja solo la manzana encima como etiqueta, y un resalte sutil
        // cuando está seleccionada/hover para que siga siendo obvio que es clickeable.
        int achTabX1 = bx + TAB_X1, achTabX2 = bx + TAB_X2;
        int achTabY1 = by + TAB_Y1[5], achTabY2 = by + TAB_Y2[5];
        boolean achTabSelected = selectedTab == 5;
        boolean overAchTab = mouseX >= achTabX1 && mouseX <= achTabX2
                           && mouseY >= achTabY1 && mouseY <= achTabY2;
        if (achTabSelected || overAchTab) {
            g.fill(achTabX1, achTabY1, achTabX2, achTabY2,
                achTabSelected ? 0x40FFFFFF : 0x22FFFFFF);
        }
        if (overAchTab) {
            String tip = tabs.get(5).label();
            int tw = mc.font.width(tip) + 4;
            drawTooltip(g, achTabX1 - tw - 3, achTabY1 + ((achTabY2 - achTabY1) - (mc.font.lineHeight + 2)) / 2, tip);
        }
        long logoNow = System.currentTimeMillis();
        int logoFrameIdx = (int) ((logoNow / LOGO_FRAME_MS) % LOGO_FRAME_COUNT);
        int logoIconH = 12;
        int logoIconW = Math.round(logoIconH * (LOGO_FRAME_W / (float) LOGO_FRAME_H));
        int logoIconX = achTabX1 + (TAB_X2 - TAB_X1 - logoIconW) / 2;
        int logoIconY = achTabY1 + (achTabY2 - achTabY1 - logoIconH) / 2;
        g.pose().pushMatrix();
        g.pose().translate(logoIconX, logoIconY);
        g.pose().scale(logoIconW / (float) LOGO_FRAME_W, logoIconH / (float) LOGO_FRAME_H);
        g.blit(RenderPipelines.GUI_TEXTURED, LOGO_FRAMES[logoFrameIdx], 0, 0, 0f, 0f,
            LOGO_FRAME_W, LOGO_FRAME_H, LOGO_FRAME_W, LOGO_FRAME_H);
        g.pose().popMatrix();
    }

    /**
     * Dibuja el ícono del creeper, centrado horizontalmente sobre el botón (TAB_CREEPER_*)
     * y anclado por ARRIBA a donde el lomo (tapa) se vuelve sólido (CREEPER_TOP_Y) en su
     * posición de descanso final. revealStep/totalSteps controla cuánto se ve, recortado
     * con scissor ANCLADO POR ABAJO — es decir, crece hacia ARRIBA (como si fuera
     * saliendo/deslizándose desde abajo de la página hasta llegar a su lugar): revealStep
     * == totalSteps muestra el ícono completo; valores menores sólo muestran la porción
     * inferior (la más cercana a la página), no la superior — usado durante el revelado
     * escalonado al pasar de página.
     */
    private void drawCreeperIcon(GuiGraphicsExtractor g, int bx, int by, int revealStep, int totalSteps) {
        if (revealStep <= 0) return;
        int h = CREEPER_ICON_DISPLAY_H;
        int w = Math.round(h * (CREEPER_ICON_W / (float) CREEPER_ICON_H));
        int x1 = bx + TAB_CREEPER_X1, x2 = bx + TAB_CREEPER_X2;
        int ix = x1 + ((x2 - x1) - w) / 2;
        int iy = by + CREEPER_TOP_Y;
        int visibleH = revealStep >= totalSteps ? h : Math.round(h * (revealStep / (float) totalSteps));
        if (visibleH <= 0) return;
        // Ventana de recorte anclada al borde INFERIOR (iy+h) y creciendo hacia arriba,
        // en vez de anclada arriba creciendo hacia abajo.
        g.enableScissor(ix, iy + h - visibleH, ix + w, iy + h);
        g.pose().pushMatrix();
        g.pose().translate(ix, iy);
        g.pose().scale(w / (float) CREEPER_ICON_W, h / (float) CREEPER_ICON_H);
        g.blit(RenderPipelines.GUI_TEXTURED, CREEPER_ICON, 0, 0, 0f, 0f, CREEPER_ICON_W, CREEPER_ICON_H, CREEPER_ICON_W, CREEPER_ICON_H);
        g.pose().popMatrix();
        g.disableScissor();
    }

    /**
     * Tooltip simple (fondo + texto) para pestañas y botones nuevos. (x,y) es la
     * esquina superior izquierda de la caja del tooltip — el llamador decide dónde
     * ubicarla según de qué lado hay espacio.
     */
    private void drawTooltip(GuiGraphicsExtractor g, int x, int y, String text) {
        Minecraft mc = Minecraft.getInstance();
        int pad = 2;
        int w = mc.font.width(text) + pad * 2;
        int h = mc.font.lineHeight + pad;
        g.fill(x, y, x + w, y + h, 0xEE000000);
        g.text(mc.font, Component.literal("§f" + text), x + pad, y + pad / 2, ARGB.opaque(0xFFFFFF), false);
    }

    /** "3/8" — completadas/total de una pestaña de categoría (índice en `tabs`). */
    private String progressString(int tabIndex) {
        Minecraft mc = Minecraft.getInstance();
        UUID uuid = mc.player != null ? mc.player.getUUID() : null;
        List<QuestEntry> qs = tabs.get(tabIndex).quests();
        int total = qs.size(), done = 0;
        if (uuid != null) {
            for (QuestEntry q : qs) if (QuestData.get().isCompleted(uuid, q.id())) done++;
        }
        return done + "/" + total;
    }

    /**
     * Dibuja un ícono animado (loop de N frames) centrado sobre una de las 5 pestañas
     * de la derecha, con resalte sutil al pasar el mouse o si está seleccionada.
     * tabArrayIndex = índice dentro de TAB_Y1/TAB_Y2 (0-4). targetTab = valor de
     * selectedTab al que corresponde esa pestaña (1=Explorador ... 5=Logros).
     */
    private void drawAnimatedTabIcon(GuiGraphicsExtractor g, int bx, int by, int mouseX, int mouseY,
            int tabArrayIndex, int targetTab, String label,
            Identifier[] frames, int frameCount, int frameW, int frameH, int frameMs, int iconH) {
        int tX1 = bx + TAB_X1, tX2 = bx + TAB_X2;
        int tY1 = by + TAB_Y1[tabArrayIndex], tY2 = by + TAB_Y2[tabArrayIndex];
        boolean selected = selectedTab == targetTab;
        boolean over = mouseX >= tX1 && mouseX <= tX2 && mouseY >= tY1 && mouseY <= tY2;
        if (selected || over) {
            g.fill(tX1, tY1, tX2, tY2, selected ? 0x40FFFFFF : 0x22FFFFFF);
        }
        int frameIdx = (int) ((System.currentTimeMillis() / frameMs) % frameCount);
        int iconW = Math.round(iconH * (frameW / (float) frameH));
        int iconX = tX1 + (TAB_X2 - TAB_X1 - iconW) / 2;
        int iconY = tY1 + (tY2 - tY1 - iconH) / 2;
        g.pose().pushMatrix();
        g.pose().translate(iconX, iconY);
        g.pose().scale(iconW / (float) frameW, iconH / (float) frameH);
        g.blit(RenderPipelines.GUI_TEXTURED, frames[frameIdx], 0, 0, 0f, 0f, frameW, frameH, frameW, frameH);
        g.pose().popMatrix();
        if (over) {
            String tip = label + " (" + progressString(targetTab) + ")";
            int tw = Minecraft.getInstance().font.width(tip) + 4;
            drawTooltip(g, tX1 - tw - 3, tY1 + (tY2 - tY1 - (Minecraft.getInstance().font.lineHeight + 2)) / 2, tip);
        }
    }

    /** Trunca el texto si es más ancho que maxWidth px */
    private static String truncate(Minecraft mc, String text, int maxWidth) {
        if (mc.font.width(text) <= maxWidth) return text;
        while (text.length() > 1 && mc.font.width(text + "...") > maxWidth)
            text = text.substring(0, text.length() - 1);
        return text + "...";
    }

    /**
     * Reparte el texto en líneas que quepan en maxWidth px, cortando por palabra completa
     * (nunca a la mitad de una palabra). A diferencia de truncate(), no pierde contenido:
     * si una línea no entra, la palabra sobrante pasa a la siguiente línea.
     */
    private static List<String> wrapText(Minecraft mc, String text, int maxWidth) {
        List<String> lines = new ArrayList<>();
        String[] words = text.split(" ");
        StringBuilder current = new StringBuilder();
        for (String word : words) {
            String candidate = current.isEmpty() ? word : current + " " + word;
            if (mc.font.width(candidate) <= maxWidth || current.isEmpty()) {
                current = new StringBuilder(candidate);
            } else {
                lines.add(current.toString());
                current = new StringBuilder(word);
            }
        }
        if (!current.isEmpty()) lines.add(current.toString());
        return lines;
    }

    // Reproduce el sonido de pasar página completo, sin recortar, apenas empieza la animación.
    // No importa que dure más o menos que la animación visual (600ms): se deja sonar entero.
    private void playPageFlipSound() {
        Minecraft.getInstance().getSoundManager().play(
            SimpleSoundInstance.forUI(ModSounds.PAGE_FLIP, 1.0f)
        );
    }

    // Chime de logro/desafío completado — mismo sonido que usa el juego para el toast
    // de advancements, así que ya se siente "propio" del juego sin necesitar un audio
    // custom para esto.
    private void playClaimSound() {
        Minecraft.getInstance().getSoundManager().play(
            SimpleSoundInstance.forUI(SoundEvents.UI_TOAST_CHALLENGE_COMPLETE, 1.0f)
        );
    }

    // Click corto y discreto para fijar/desfijar y para el toggle de "ocultar completadas".
    private void playClickSound() {
        Minecraft.getInstance().getSoundManager().play(
            SimpleSoundInstance.forUI(SoundEvents.UI_BUTTON_CLICK, 1.0f)
        );
    }

    private void handleClick(double mx, double my) {
        // Ignorar clicks mientras se reproduce la animación de cambio de página
        if (tabAnimStart >= 0 && (System.currentTimeMillis() - tabAnimStart) < ANIM_TOTAL_MS) return;

        // Botón de opciones (⚙): reabre la ventana de elegir idioma, por si alguien
        // se equivocó la primera vez. Se chequea primero porque es fijo en toda pestaña.
        if (mx >= optionsBtnX && mx <= optionsBtnX + optionsBtnW
                && my >= optionsBtnY && my <= optionsBtnY + optionsBtnH) {
            Minecraft.getInstance().gui.setScreen(new LanguageSelectScreen());
            return;
        }

        int bx = this.width  / 2 - BW / 2;
        int by = this.height / 2 - BH / 2;

        double rx = mx - bx, ry = my - by;

        // Click en pestaña Principal (icono casita arriba izquierda)
        if (rx >= TAB_HOME_X1 && rx <= TAB_HOME_X2
                && ry >= TAB_HOME_Y1 && ry <= TAB_HOME_Y2) {
            if (selectedTab != 0) { tabAnimStart = System.currentTimeMillis(); playPageFlipSound(); }
            selectedTab = 0; selectedIndex = -1; return;
        }

        // Click en botón creeper (arriba izquierda, junto a la casita): pestaña
        // "Completadas" — misiones completadas de las 4 categorías, sin canjear
        // primero, canjeadas después (ver buildCompletedQuests()).
        if (rx >= TAB_CREEPER_X1 && rx <= TAB_CREEPER_X2
                && ry >= TAB_CREEPER_Y1 && ry <= TAB_CREEPER_Y2) {
            if (selectedTab != TAB_COMPLETED) { tabAnimStart = System.currentTimeMillis(); playPageFlipSound(); }
            selectedTab = TAB_COMPLETED; selectedIndex = -1; return;
        }

        // Click en pestañas derecha: Explorador/Minero/Constructor/Técnico/Mago/Logros.
        // Ya no es un simple "+1" — los últimos dos slots están invertidos respecto al
        // número de pestaña (Mago vive en el slot 4 pero es la pestaña 6, Logros vive
        // en el slot 5 pero sigue siendo la pestaña 5).
        if (rx >= TAB_X1 && rx <= TAB_X2) {
            for (int i = 0; i < TAB_Y1.length; i++) {
                if (ry >= TAB_Y1[i] && ry <= TAB_Y2[i]) {
                    int newTab = TAB_SLOT_TO_SELECTED[i];
                    if (selectedTab != newTab) { tabAnimStart = System.currentTimeMillis(); playPageFlipSound(); }
                    selectedTab = newTab;
                    selectedIndex = -1;
                    return;
                }
            }
        }

        // Click en flecha ▲
        if (mx >= scrollBtnX && mx <= scrollBtnX + 10
                && my >= scrollUpBtnY && my <= scrollUpBtnY + 9) {
            scrollUp(); return;
        }
        // Click en flecha ▼
        if (mx >= scrollBtnX && mx <= scrollBtnX + 10
                && my >= scrollDownBtnY && my <= scrollDownBtnY + 9) {
            scrollDown(); return;
        }

        // Click en toggle "ocultar completadas"
        if (my >= hideToggleY && my <= hideToggleY + hideToggleSize
                && mx >= hideToggleX && mx <= hideToggleX + hideToggleSize) {
            hideCompleted = !hideCompleted;
            selectedIndex = -1; // el índice seleccionado ya no vale con la lista filtrada distinta
            playClickSound();
            return;
        }

        // Click en "Reclamar todo" (Completadas)
        if (my >= claimAllBtnY && my <= claimAllBtnY + claimAllBtnH
                && mx >= claimAllBtnX && mx <= claimAllBtnX + claimAllBtnW) {
            for (QuestEntry q : unclaimedCompletedQuests()) {
                ClientPlayNetworking.send(new ClaimRewardPayload(q.id()));
            }
            playClaimSound();
            return;
        }

        // Click en lista de misiones
        List<QuestEntry> quests = currentTabQuests();
        int lx  = bx + PAGE_L_X;
        int ly  = by + PAGE_L_Y + ROW_H;
        int off = scrollOffset[selectedTab];
        int end = Math.min(quests.size(), off + VISIBLE_ROWS);
        for (int i = off; i < end; i++) {
            if (mx >= lx - 2 && mx <= lx + PAGE_L_W - 2 && my >= ly - 1 && my <= ly + 12) {
                selectedIndex = (selectedIndex == i) ? -1 : i;
                return;
            }
            ly += ROW_H;
        }

        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || selectedIndex < 0 || selectedIndex >= quests.size()) return;
        UUID uuid = mc.player.getUUID();
        QuestEntry q = quests.get(selectedIndex);

        // Botón Obtener
        if (claimBtnQuestId != null
                && my >= claimBtnY && my <= claimBtnY + claimBtnH
                && mx >= claimBtnX && mx <= claimBtnX + claimBtnW) {
            ClientPlayNetworking.send(new ClaimRewardPayload(claimBtnQuestId));
            playClaimSound();
            return;
        }

        // Botón Fijar
        if (my >= pinBtnY && my <= pinBtnY + pinBtnH
                && mx >= pinBtnX && mx <= pinBtnX + pinBtnW) {
            if (!QuestData.get().isCompleted(uuid, q.id())) {
                if (q.id().equals(QuestData.get().getPinnedQuest(uuid)))
                    QuestData.get().unpinQuest(uuid);
                else
                    QuestData.get().pinQuest(uuid, q.id());
                playClickSound();
            }
        }
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent click, boolean doubled) {
        if (click.button() == 0) handleClick(click.x(), click.y());
        return super.mouseClicked(click, doubled);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        // Scroll con rueda del ratón cuando el cursor está sobre la página izquierda
        int bx = this.width  / 2 - BW / 2;
        int by = this.height / 2 - BH / 2;
        boolean overLeft = mouseX >= bx + PAGE_L_X - 2
                        && mouseX <= bx + PAGE_L_X + PAGE_L_W
                        && mouseY >= by + PAGE_L_Y
                        && mouseY <= by + PAGE_L_Y + PAGE_L_H;
        if (overLeft) {
            if (verticalAmount > 0) scrollUp();
            else if (verticalAmount < 0) scrollDown();
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override public boolean isPauseScreen() { return false; }
}
